function CreateGanttDiagram(solution,IndexofProblem)
Solution=solution.operationsSchedule;
jobsCount=max(Solution(:,2));
operationsCount=Solution(end,1);
machinesCount=max(Solution(:,7));
xmin=min(Solution(:,5))-1;
xmax=max(Solution(:,6))+1;
figure;
for i=1:machinesCount
    X=[xmin xmax];
    Y=[i i];
    plot(X,Y,'k','LineWidth',20);
    hold on;
end
C=hsv(jobsCount);
for j=1:operationsCount
    i=Solution(j,2);
    y1=Solution(j,7);
    y2=Solution(j,7);
    x1=Solution(j,5);
    x2=Solution(j,6);
    X=[x1 x2];
    Y=[y1 y2];
    plot(X,Y,'Color',C(i,:),'LineWidth',17);
    plot(x1,y1,'r.');
    plot(x2,y2,'r.');
    str=num2str(x1);
    text(x1,(y1-0.3),cellstr(str),'FontSize',10,'Color',C(i,:));
    str=num2str(x2);
    text(x2,(y2+0.3),cellstr(str),'FontSize',10,'Color',C(i,:));
    
    xlabel('Time');
    ylabel('Machines');
    %title('Gantt');
    text(x1,y1,num2str(j),'FontSize',12);
    hold on;
end
grid on;
hold off;
xlim([xmin xmax]);
ylim([0 machinesCount+1]);

set(gcf, 'Position',[ 10 10 1500 800]);
set(gca, 'Position',[ .02 .025 .97 .97]);
EnergyResult=['TEC  ',num2str(solution.obj),'     MS  ',num2str(solution.Cmax),'   Pt  ',num2str(solution.PtPc),'   SwitchOff  ',num2str(solution.OnOffStEng)];
annotation('textbox',[0.03,0.03,0.3,0.03],'String',EnergyResult);
FileName=IndexofProblem;

saveas(gcf,FileName,'jpg');

end