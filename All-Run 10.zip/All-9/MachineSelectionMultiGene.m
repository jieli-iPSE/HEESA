function [schedulingMatrics] = MachineSelectionMultiGene(schedulingMatrics,problemSet,Chromosome,LastRow,LeftRight,GeneNumber)
comparedOperationsRow=find(schedulingMatrics.nextEventsList(:,2)~=3);
comparedOperation=schedulingMatrics.nextEventsList(comparedOperationsRow,3);
schedulingMatrics.recentlyAssignedOperations=[];
schedulingMatrics.recentlyAssignedMachines=[];
machinesStartTimes=schedulingMatrics.machinesStartTimes;
schedulingMatrics.machinesWaitingList(schedulingMatrics.machinesWaitingList>0)=0;
    
for i=1:size(comparedOperation,1)
    operation=comparedOperation(i);
    tempAssignableMachinesList=cell2mat(problemSet.operationsSet(operation,5))';
    tempAssignableMachinesProcessingTimes=cell2mat(problemSet.operationsSet(operation,6))';
    tempAssignableMachinesPCs=cell2mat(problemSet.operationsSet(operation,8))';
    numberOfAssignableMachines=numel(tempAssignableMachinesList);
    
    relatedJob=cell2mat(problemSet.operationsSet(operation,2));
    relatedJobOperationNumber=cell2mat(problemSet.jobsSet(relatedJob,4));
    orderInJob=cell2mat(problemSet.operationsSet(operation,3));
    nr=relatedJobOperationNumber-orderInJob;
    
    tempAssignableMachinesValues=zeros(numberOfAssignableMachines,1);
    if numberOfAssignableMachines>1
        for j=1:numberOfAssignableMachines
            pt=tempAssignableMachinesProcessingTimes(j,1);
            pc=tempAssignableMachinesPCs(j,1);
            machine=tempAssignableMachinesList(j);
            pu=problemSet.machinesSet{machine,5};
            startTimeofMachine=machinesStartTimes(machine,2);
            RowofoperationinNextEventsList=find(schedulingMatrics.nextEventsList(:,3)==operation);
            if numel(RowofoperationinNextEventsList)>1
                k=1;
                while k<=numel(RowofoperationinNextEventsList)
                    if schedulingMatrics.nextEventsList(RowofoperationinNextEventsList(k),2)==3
                        RowofoperationinNextEventsList(k)=[];
                        k=k-1;
                    end
                    k=k+1;
                end
            end
            releaseTimeofOperation=schedulingMatrics.nextEventsList(RowofoperationinNextEventsList,1);
            it=releaseTimeofOperation-startTimeofMachine;
            if machinesStartTimes(machine,2)==0
                it=0;
            end
            it=max(0,it);
                            
            priority=calculatePriorityMultiGene(it,nr,pt,pc,pu,Chromosome,LastRow,LeftRight,GeneNumber);
            tempAssignableMachinesValues(j,1)=priority;
        end
    else
        tempAssignableMachinesValues=1;
    end

    [~,index]=min(tempAssignableMachinesValues);
    machine=tempAssignableMachinesList(index,1);
    schedulingMatrics.machinesWaitingList(machine,operation)=1;
    schedulingMatrics.recentlyAssignedOperations(end+1,1)=operation;
    schedulingMatrics.recentlyAssignedMachines(end+1,1)=machine;
end


end

