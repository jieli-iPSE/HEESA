function [OnOffStanbyEnergyOfMachines]=CalculateOnOffStanbyEnergy(problemSet,solution)
%[problemSet] = FJSSPReadProblemSet(benchmark);
operationsAssignmentResults=solution.operationsSchedule;
machinesCount=problemSet.problemSize.machinesNumber;
OnOffStanbyEnergyOfMachines=zeros(machinesCount,1);
for i=1:machinesCount
    thismachinetable=operationsAssignmentResults(operationsAssignmentResults(:,7)==i,:);
    [~,o]=sort(thismachinetable(:,5));
    thismachinetable=thismachinetable(o,:);
    assignedoperationscount=numel(solution.machinesSchedule{i,1});
    Pu=problemSet.machinesSet{i,5};
    Eo=problemSet.machinesSet{i,6};
    %if assignedoperationscount==1
        %OnOffStanbyEnergyOfMachines(i,1)=Eo;
        %continue
    %end
    for j=1:assignedoperationscount-1
        %if j==1
            %if thismachinetable(j,5)>=0
                %OnOffStanbyEnergyOfMachines(i)=Eo;
            %end
        %elseif thismachinetable(j+1,5)>thismachinetable(j,6)
        if thismachinetable(j+1,5)>thismachinetable(j,6)
                it=thismachinetable(j+1,5)-thismachinetable(j,6);
                OnOffStanbyEnergyOfMachines(i)=min(Eo,it*Pu)+OnOffStanbyEnergyOfMachines(i);
        end
    end
%OnOffStanbyEnergyOfMachines(i)=Eo+OnOffStanbyEnergyOfMachines(i);
end
end