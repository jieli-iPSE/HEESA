function [child1,child2] = GEPCrossoverMultiGene(parent1,parent2,GeneNumber,GeneSize)
Parent1Chromsome=parent1.chromosome;
Parent2Chromsome=parent2.chromosome;
child1.chromosome=cell(2,1);
child2.chromosome=cell(2,1);
for j=1:2   % one for sequence, one for assignment
    chromosome1=Parent1Chromsome{j};
    chromosome2=Parent2Chromsome{j};
    ChromosomeChild1=cell(GeneNumber,1);
    ChromosomeChild2=cell(GeneNumber,1);
    for i=1:(GeneNumber+1)
        
        Gene1=chromosome1{i};
        Gene2=chromosome2{i};
        position=randi([2,GeneSize-1],1,1);
        
        parent11=Gene1(:,1:position);
        parent12=Gene1(:,position+1:end);
        
        parent21=Gene2(:,1:position);
        parent22=Gene2(:,position+1:end);
        
        ChromosomeChild1{i}=[parent11,parent22];
        ChromosomeChild2{i}=[parent21,parent12];
    end
    child1.chromosome{j}=ChromosomeChild1;
    child2.chromosome{j}=ChromosomeChild2;
end
end

