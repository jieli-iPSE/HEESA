function [Solution]=SH_VND323(solution,problemSet,KnowledgeBaseMachine)
%% Explanation
% NeighborhoodStructure1: Exchange
% NeighborhoodStructure2; Change Position of two jobs

% NeighborhoodStructure3: Operation after idle time exchange position with its successor operation
% NeighborhoodStructure4: Operation before idle time insert into the first position

%% Inner loop 
% ** current best solution and MIN TEC
Cur_TEC=solution.solutionRightLiftMove.obj;
Cur_Solution=solution;


%% Shaking
Mmax=3;   % number of Neighborhood structure in shaking =3. ExchangeJob,InsertionJob,MachineMutationKnowledgeGuided
solution_VNSIF=shaking(Cur_Solution,problemSet,Mmax,KnowledgeBaseMachine);
TEC_VNSIF=solution_VNSIF.solutionRightLiftMove.obj;

%% VND
m=1;
Mmax=25;
% solution_EGSM2=solution_VNSIF;
if TEC_VNSIF<Cur_TEC
    % shaking find a better solution than current best, gen=1; 
    Cur_Solution=solution_VNSIF;
else
    while m<=Mmax
%         m
        if m==23
            %% Energy guided machine changes
            solution_EGSM2=VNSEnergyGuidedCrossMachineMoving(solution_EGSM2,problemSet);
            TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
            
            if TEC_EGSM2<TEC_VNSIF
                TEC_VNSIF=TEC_EGSM2;
                solution_VNSIF=solution_EGSM2;
                m=1;
            else
                m=m+1;
            end
            if TEC_VNSIF<Cur_TEC
                Cur_TEC=TEC_VNSIF;
                Cur_Solution=solution_VNSIF;
                m=Mmax+1;
            end
        else
            if m==24
                %% Energy guided swap operations after idle solts
                solution_EGSM2=VNSEnergyGuidedSameMachineMoving1(solution_EGSM2,problemSet);
                TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                
                if TEC_EGSM2<TEC_VNSIF
                    TEC_VNSIF=TEC_EGSM2;
                    solution_VNSIF=solution_EGSM2;
                    m=1;
                else
                    m=m+1;
                end
                if TEC_VNSIF<Cur_TEC
                    Cur_TEC=TEC_VNSIF;
                    Cur_Solution=solution_VNSIF;
                    m=Mmax+1;
                end
            else
                if m==22
                  %% Energy guided swap operations related to idel slot in other machine
                    solution_EGSM2=VNSEnergyGuidedSameMachineMoving2(solution_EGSM2,problemSet);
                    TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                    
                    if TEC_EGSM2<TEC_VNSIF
                        TEC_VNSIF=TEC_EGSM2;
                        solution_VNSIF=solution_EGSM2;
                        m=1;
                    else
                        m=m+1;
                    end
                    if TEC_VNSIF<Cur_TEC
                        Cur_TEC=TEC_VNSIF;
                        Cur_Solution=solution_VNSIF;
                        m=Mmax+1;
                    end
                else
                    if m==5|| m==9 || m==14 || m==18 || m==25
                     %% Machine adjustment 
                        solution_EGSM2=VNS_MachineMutationFinishTimeGuided(solution_EGSM2,problemSet);
                        TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                        
                        if TEC_EGSM2<TEC_VNSIF
                            TEC_VNSIF=TEC_EGSM2;
                            solution_VNSIF=solution_EGSM2;
                            m=1;
                        else
                            m=m+1;
                        end
                        if TEC_VNSIF<Cur_TEC
                            Cur_TEC=TEC_VNSIF;
                            Cur_Solution=solution_VNSIF;
                            m=Mmax+1;
                        end
                    else
                        if m==4 || m==13
                        %% Insertion Job
                            solution_EGSM2=VNS_InsertionJobRandom(solution_EGSM2,problemSet);
                            TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                            
                            if TEC_EGSM2<TEC_VNSIF
                                TEC_VNSIF=TEC_EGSM2;
                                solution_VNSIF=solution_EGSM2;
                                m=1;
                            else
                                m=m+1;
                            end
                            if TEC_VNSIF<Cur_TEC
                                Cur_TEC=TEC_VNSIF;
                                Cur_Solution=solution_VNSIF;
                                m=Mmax+1;
                            end
                        else
                            if m==1 || m==6 || m==10|| m==15 || m==19 
                                %% Operation swap
                                solution_EGSM2=VNS_OperationSwapOnMachineRandom(solution_VNSIF,problemSet);
                                TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                                
                                if TEC_EGSM2<TEC_VNSIF
                                    TEC_VNSIF=TEC_EGSM2;
                                    solution_VNSIF=solution_EGSM2;
                                    m=1;
                                else
                                    m=m+1;
                                end
                                if TEC_VNSIF<Cur_TEC
                                    Cur_TEC=TEC_VNSIF;
                                    Cur_Solution=solution_VNSIF;
                                    m=Mmax+1;
                                end
                            else
                                if m==2 || m==7 || m==11 || m==16 || m==20
                                    
                                    %% Random operation insertion backforward
                                    solution_EGSM2=VNS_OperationInsertionBackwardOnMachineRandom(solution_EGSM2,problemSet);
                                    TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                                    
                                    if TEC_EGSM2<TEC_VNSIF
                                        TEC_VNSIF=TEC_EGSM2;
                                        solution_VNSIF=solution_EGSM2;
                                        m=1;
                                    else
                                        m=m+1;
                                    end
                                    if TEC_VNSIF<Cur_TEC
                                        Cur_TEC=TEC_VNSIF;
                                        Cur_Solution=solution_VNSIF;
                                        m=Mmax+1;
                                    end
                                else
                                    if m==3 || m==8 || m==12 || m==17  || m==21  
                                        
                                %% Random operation Insertion forward
                                    solution_EGSM2=VNS_OperationInsertionOnMachineRandom(solution_EGSM2,problemSet);
                                    TEC_EGSM2=solution_EGSM2.solutionRightLiftMove.obj;
                                    
                                    if TEC_EGSM2<TEC_VNSIF
                                        TEC_VNSIF=TEC_EGSM2;
                                        solution_VNSIF=solution_EGSM2;
                                        m=1;
                                    else
                                        m=m+1;
                                    end
                                    if TEC_VNSIF<Cur_TEC
                                        Cur_TEC=TEC_VNSIF;
                                        Cur_Solution=solution_VNSIF;
                                        m=Mmax+1;
                                    end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

Solution=Cur_Solution;
end