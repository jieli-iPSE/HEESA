function operationsSchedule=MoveTypeII(operations,operationsSchedule,operationsScheduleAfterRightMove,LastOperationsOfJobs,Machine,MachineTime,EndingTimeOfThisBlock)
Movingstep=zeros(numel(operations),1);
for i=1:numel(operations)
    operation=operations(i);
    Movingstep(i,1)=operationsScheduleAfterRightMove(operation,4)-operationsSchedule(operation,6);
    ind=find(LastOperationsOfJobs==operation);
    if numel(ind)==0
        % if the operation in not the last operation of its job, and its next operation of the same job belongs to the same block as it
        ind2=find(operations==operation+1);
        if numel(ind2)==1
            Movingstep(i,1)=inf;
        end
    end
end
durationLength=MachineTime(Machine,1)-EndingTimeOfThisBlock;
length=min(min(Movingstep),durationLength);
if length==durationLength
    % Moving all block to omit the idel interval after the block
    for i=1:numel(operations)
        operation=operations(i);
        operationsSchedule(operation,6)=operationsSchedule(operation,6)+length;
        operationsSchedule(operation,5)=operationsSchedule(operation,5)+length;
    end
else
    %
    subBlock2=[];
    subBlock1=operations;
    for i=numel(operations):-1:1
        if Movingstep(i,1)>=durationLength
            subBlock2=[subBlock2,operations(i)];
            subBlock1(find(subBlock1==operations(i)))=[];
        else
            break;
        end
    end
    step_subBlock2=durationLength;
    for i=1:numel(subBlock2)
        operation=subBlock2(i);
        operationsSchedule(operation,6)=operationsSchedule(operation,6)+step_subBlock2;
        operationsSchedule(operation,5)=operationsSchedule(operation,5)+step_subBlock2;
    end
    step_subBlock1=length;
    for i=1:numel(subBlock1)
        operation=subBlock1(i);
        operationsSchedule(operation,6)=operationsSchedule(operation,6)+step_subBlock1;
        operationsSchedule(operation,5)=operationsSchedule(operation,5)+step_subBlock1;
    end
end
end