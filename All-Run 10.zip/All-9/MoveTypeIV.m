function operationsSchedule=MoveTypeIV(LastOperationsOnMachines,operations,operationsSchedule,operationsScheduleAfterRightMove,FirstOperationsOfJobs,Machine,MachineTime,EndingTimeOfThisBlock)
Movingstep1=zeros(numel(operations),1);
Movingstep2=zeros(numel(operations),1);
for i=1:numel(operations)
    operation=operations(i);
    Movingstep1(i,1)=operationsScheduleAfterRightMove(operation,4)-operationsSchedule(operation,6);
    ind=find(FirstOperationsOfJobs==operation);
    if numel(ind)==0
        % if the operation in not the first operation of its job
        FormerOperationOfSameJob=operation-1;
        WhetherLastOperationOnMachine=find(LastOperationsOnMachines==FormerOperationOfSameJob);
        if numel(WhetherLastOperationOnMachine)==0
            EndtimeOfFormerOperation=operationsSchedule(FormerOperationOfSameJob,6);
            MachineOfFormerOperation=operationsSchedule(FormerOperationOfSameJob,7);
            
            Index=find(operationsSchedule(:,7)==MachineOfFormerOperation & operationsSchedule(:,5)>=EndtimeOfFormerOperation);
            startingTimeOfThisOperation=operationsSchedule(operation,5);
            if min(operationsSchedule(Index,5))>startingTimeOfThisOperation && (startingTimeOfThisOperation+Movingstep1(i,1)>=min(operationsSchedule(Index,5)))
                LengthOfIdelAfterFormerOperationOfSameJob=min(operationsSchedule(Index,5))-startingTimeOfThisOperation;
                Movingstep2(i,1)=LengthOfIdelAfterFormerOperationOfSameJob;
            end
        end
    end
end
durationLength=MachineTime(Machine,1)-EndingTimeOfThisBlock;
Length=min(min(Movingstep1),min(max(Movingstep2),durationLength));
for i=1:numel(operations)
    operation=operations(i);
    operationsSchedule(operation,6)=operationsSchedule(operation,6)+Length;
    operationsSchedule(operation,5)=operationsSchedule(operation,5)+Length;
end

end
        