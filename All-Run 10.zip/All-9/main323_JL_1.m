function Result=main323()
% clear;
clc;
% close all;

functionsNumber=5;
elementsSize=5;
i=1;

%% i=1: smallsizeProblem

if i==1
    maxIteration=10;
    nPop=100;
    headSize=5;
    GeneNumber=1;
    crossoverRate=0.6;
    mutationRate=0.3;
    TranspositionRate=0;
    MAXGENVNS=50;
    % Write Parameters into Excel--------------------------------------------------
    %row 1 in Excel
    Parameter=['maxIteration=',num2str(maxIteration),'  nPop=',num2str(nPop),'  headSize=',num2str(headSize),'      GeneNumber',num2str(GeneNumber),'  crossoverRate=',num2str(crossoverRate),'  mutationRate=',num2str(mutationRate),'  TranspositionRate=',num2str(TranspositionRate),'     MaxGenVNS=', num2str(MAXGENVNS)];
    %row 2 in Excel
    Index=[];
    for j=1:maxIteration
        Name=['  Gen',num2str(j)];
        Index=[Index,Name]; %#ok<AGROW>
    end
    Index=[Index,'  Final'];
    
    xlswrite('Result.xlsx',cellstr(Parameter),'Small','A1:A1');
    xlswrite('Result.xlsx',cellstr(Index),'Small','A2:A2');
    
    %--------------------------------------------------
    for j=1:20
        
        close all;

        IndexofProblem=['Problem',num2str(j)];
        benchmark = xlsread("SmallData.xlsx",IndexofProblem);

        [Result,CPU]=AdaptivePGEP323(IndexofProblem,benchmark,nPop,maxIteration,headSize,GeneNumber,functionsNumber,elementsSize,crossoverRate,mutationRate,MAXGENVNS);

        P=num2str(j+2);
        Result=[j,Result]; %#ok<AGROW>
        time=[j,CPU];
        xlswrite('Result.xlsx',Result,'Small',P);
        xlswrite('Result.xlsx',time,'Small-CPU',P);
    end
end

%% 2:Mediumsize

%%%i=2;
if i==2
    maxIteration=100;
    nPop=100;
    headSize=5;
    GeneNumber=3;
    crossoverRate=0.6;
    mutationRate=0.3;
    TranspositionRate=0;
    MAXGENVNS=500;
    % Write Parameters into Excel--------------------------------------------------
    %row 1 in Excel
    Parameter=['maxIteration=',num2str(maxIteration),'  nPop=',num2str(nPop),'  headSize=',num2str(headSize),'      GeneNumber',num2str(GeneNumber),'  crossoverRate=',num2str(crossoverRate),'  mutationRate=',num2str(mutationRate),'  TranspositionRate=',num2str(TranspositionRate),'     MaxGenVNS=', num2str(MAXGENVNS)];
    %row 2 in Excel
    Index=[];
    for j=1:maxIteration
        Name=['  Gen',num2str(j)];
        Index=[Index,Name]; %#ok<AGROW>
    end
    Index=[Index,'  Final'];
    
    xlswrite('Result.xlsx',cellstr(Parameter),'FT','A1:A1');
    xlswrite('Result.xlsx',cellstr(Index),'FT','A2:A2');

    %--------------------------------------------------
    for j=1:3
         IndexofProblem=[];
        if j==1
            IndexofProblem=['FT0',num2str(6)];
        end
        if j==2
            IndexofProblem=['FT',num2str(10)];
        end
        if j==3
            IndexofProblem=['FT',num2str(20)];
        end
        close all;
        benchmark = xlsread("LargeData.xlsx",IndexofProblem);

        [Result,CPU]=AdaptivePGEP323(IndexofProblem,benchmark,nPop,maxIteration,headSize,GeneNumber,functionsNumber,elementsSize,crossoverRate,mutationRate,MAXGENVNS);

        P=num2str(j+2);
        Result=[j,Result]; %#ok<AGROW>
        time=[j,CPU];
        xlswrite('Result.xlsx',Result,'FT',P);

        xlswrite('Result.xlsx',time,'FT-CPU',P);
    end
end

%% 3: LargesizeProblem
%%%i=3;
if i==3
    maxIteration=100;
    nPop=100;
    headSize=5;
    GeneNumber=3;
    crossoverRate=0.6;
    mutationRate=0.3;
    TranspositionRate=0;
    MAXGENVNS=500;
    % Write Parameters into Excel--------------------------------------------------
    %row 1 in Excel
    Parameter=['maxIteration=',num2str(maxIteration),'  nPop=',num2str(nPop),'  headSize=',num2str(headSize),'      GeneNumber',num2str(GeneNumber),'  crossoverRate=',num2str(crossoverRate),'  mutationRate=',num2str(mutationRate),'  TranspositionRate=',num2str(TranspositionRate),'     MaxGenVNS=', num2str(MAXGENVNS)];
    %row 2 in Excel
    Index=[];
    for j=1:maxIteration
        Name=['  Gen',num2str(j)];
        Index=[Index,Name]; %#ok<AGROW>
    end
    Index=[Index,'  Final'];
    
    xlswrite('Result.xlsx',cellstr(Parameter),'LA','A1:A1');
    xlswrite('Result.xlsx',cellstr(Index),'LA','A2:A2');
    %--------------------------------------------------
    %     parfor j=1:35
    for j=1:35
        
        if j<10
            IndexofProblem=['LA0',num2str(j)];
        else
            IndexofProblem=['LA',num2str(j)];
        end
        close all;
        benchmark = xlsread("LargeData.xlsx",IndexofProblem);
        
        [Result,CPU]=AdaptivePGEP323(IndexofProblem,benchmark,nPop,maxIteration,headSize,GeneNumber,functionsNumber,elementsSize,crossoverRate,mutationRate,MAXGENVNS);
        
        P=num2str(j+2);
        Result=[j,Result]; %#ok<AGROW>
        time=[j,CPU];
        xlswrite('Result.xlsx',Result,'LA',P);
        xlswrite('Result.xlsx',time,'LA-CPU',P);
    end

end

end