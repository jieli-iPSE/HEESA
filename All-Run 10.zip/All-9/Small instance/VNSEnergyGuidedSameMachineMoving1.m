function solutionV=VNSEnergyGuidedSameMachineMoving1(solution,problemSet)

%% Moving of operations on the same machine is carried out based on the solution obtained from earliest starting strategy
%% For each idle slot, swap the operation A and B after it to reduce the duration of the idel slot. Please see the explanation File name 'Energy Guided Same Machine Moving1'

%%
Solution=solution.solutionEarliestStartingStrategy;

%%
% Solution is the schedule obtained based on earliest strategy and
% solution_VNSNI1 is the one after move
solution_VNSNI1.operationsSchedule=Solution.operationsSchedule;
OperationSequencingList=Solution.OperationSequencingList;
operationsSchedule=Solution.operationsSchedule;

%% Relevant data for the problem
MachineNum=problemSet.problemSize.machinesNumber;
JobNum=problemSet.problemSize.jobsNumber;
OperationNum=problemSet.problemSize.totalOperationsNumber;
LastOperationsOfJobs=zeros(JobNum,1);
FirstOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
    FirstOperationsOfJobs(i,1) =  problemSet.jobsSet{i,5}(1);
    LastOperationsOfJobs(i,1)  =  problemSet.jobsSet{i,5}(end);
end

% threshold duration of idel time on machine for switch off/on energy or standby
thresholdOfIdelTimeForMachines=ThresholdForSwitchOffOrStandby(problemSet);

%% conduct moving for all idel slots on all machines
%** Note after every move the operationsSchedule and machinesSchedule and IdlePositionOnMachine should be updated
IdlePositionOnMachine=Solution.IdlePositionOnMachine;
ColumnMax=size(Solution.IdlePositionOnMachine,1);
TotalChecked=0;
while TotalChecked==0
    Index=0;
    
    for j=1:MachineNum
        % idel time information is stored in the 2*i-1 and 2*i column
        
        for l=1:ColumnMax
            if cell2mat(IdlePositionOnMachine(l,2*j))==0 % the last operation in the machine j
                l=ColumnMax; %#ok<FXSET>
                break;
            end
            
            if isempty(cell2mat(IdlePositionOnMachine(l,2*j)))==1
                l=ColumnMax; %#ok<FXSET>
                break;
            end
            
            if cell2mat(IdlePositionOnMachine(l,2*j))~=cell2mat(IdlePositionOnMachine(min(l+1,ColumnMax),2*j-1))   %% there are one operation immediately after current operation
                
                operationJobIndex=cell2mat(IdlePositionOnMachine(l,2*j));
                operationPosition=find(OperationSequencingList(:,1)==operationJobIndex(1) & OperationSequencingList(:,2)==operationJobIndex(2));
                operation=OperationSequencingList(operationPosition(1),4);   % operation A
                
                if l==1
                    Index1=find(FirstOperationsOfJobs==operation);
                    if numel(Index1)>0
                        Index2=0; % from t=0 to the first operation, the first operation is first one of its belonging job
                    else
                        Index2=1; % the first operation at this machine is not the first one of its belonging job
                    end
                else
                    Index2=1; % idel slot is from one operation to another operation
                end
                if Index2==1
                    % operation after the target operation
                    OperationNextOnTheMachinePosition=min(operationPosition+1,OperationNum)-1+find(OperationSequencingList(min(operationPosition+1,OperationNum):OperationNum,3)==j);
                    OperationNextOnTheMachinePosition=OperationNextOnTheMachinePosition(1);
                    if OperationSequencingList(OperationNextOnTheMachinePosition(1),1)~=OperationSequencingList(operationPosition,1)   % the current operation and its adjacent one do not belong to the same job
                        operationNextOnTheMachine=OperationSequencingList(OperationNextOnTheMachinePosition(1),4);   % Operation B
                        %% whether next operation on this machine is the first operation of its job
                        IndexB=find(FirstOperationsOfJobs==operationNextOnTheMachine);
                        if numel(IndexB)==1
                            EndTimeBminus1=0;
                        else
                            EndTimeBminus1=operationsSchedule(operationNextOnTheMachine-1,6);
                        end
                        StartTimeOfOperation=operationsSchedule(operation,5);
                        if EndTimeBminus1<StartTimeOfOperation
                            % machine end time before the idel solt
                            if cell2mat(IdlePositionOnMachine(l,2*j-1))==0
                                MachineEndTime=0;
                            else
                                operationJobBeforeIndex=cell2mat(IdlePositionOnMachine(l,2*j-1));
                                operationBeforeOnTheMachine=find(operationsSchedule(:,2)==operationJobBeforeIndex(1) & operationsSchedule(:,3)==operationJobBeforeIndex(2));
                                MachineEndTime=operationsSchedule(operationBeforeOnTheMachine(1),6);
                            end
                            StartTimeOfBAfterMove=max(MachineEndTime,EndTimeBminus1);
                            ProcessingTimeOfB=operationsSchedule(operationNextOnTheMachine,6)-operationsSchedule(operationNextOnTheMachine,5);
                            ProcessingTimeOfA=operationsSchedule(operation,6)-operationsSchedule(operation,5);
                            EndTimeOfOperationAfterMove=StartTimeOfBAfterMove+ProcessingTimeOfB+ProcessingTimeOfA;
                            
                            % A+1 start time
                            IndexA=find(LastOperationsOfJobs==operation);
                            if numel(IndexA)==1
                                StartTimeAplus1=inf;
                            else
                                StartTimeAplus1=operationsSchedule(operation+1,5);
                            end
                            
                            if EndTimeOfOperationAfterMove<=StartTimeAplus1
                                % check whether idel slot would be devided by two slots
                                if StartTimeAplus1>= operationsSchedule(operationNextOnTheMachine,6) %% if A+1 start after the end of B, the slot would not be slot into two slots
                                    %% swap A and B
                                    Index=1;
                                else
                                    % calculate the maximum step of moving forward for operations after B on the machine j
                                    OperationsOnThisMachine=cell2mat(Solution.machinesSchedule(j,:));
                                    LocationB=find(OperationsOnThisMachine==operationNextOnTheMachine);
                                    if LocationB(1)==size(OperationsOnThisMachine,2)  % operation B is the last performed operation on the machine
                                        %% swap A and B
                                        Index=1;
                                    else
                                        MaxStepOfMovingForwardAfterB=inf;
                                        for o=LocationB(1)+1:size(OperationsOnThisMachine,2)
                                            operationTesting = OperationsOnThisMachine(o);
                                            MaxStepOfMovingForwardAfterB=min(operationsSchedule(operationTesting,5)-operationsSchedule(operationTesting,4),MaxStepOfMovingForwardAfterB);
                                        end
                                        % Total duration of two slots after moving
                                        DurationIdel=StartTimeOfOperation-MachineEndTime;
                                        DurationIdelOfTwoSlotsAfterMoving=DurationIdel-MaxStepOfMovingForwardAfterB;
                                        
                                        if DurationIdelOfTwoSlotsAfterMoving<=thresholdOfIdelTimeForMachines(j)
                                            %% Swap A and B
                                            Index=1;
                                        end
                                        
                                    end
                                end
                                
                                %% Swap A and B------in this step only change OperationSequencingList, other Matrix would be updated later
                                if Index==1  % A position: operationPosition B position: OperationNextOnTheMachinePosition  %% Idel,A,B
                                    
                                    %% Swap A and B  % A is before B
                                    PositionA=operationPosition;
                                    PositionB=OperationNextOnTheMachinePosition;
                                    
                                    Auxiliary=OperationSequencingList(PositionA,:);
                                    OperationSequencingList(PositionA,:)=OperationSequencingList(PositionB,:);
                                    OperationSequencingList(PositionB,:)=Auxiliary;
                                    
                                    OperationA=operation;
                                    OperationB=operationNextOnTheMachine;
                                    %% check the position between A and A+1
                                    if numel(IndexA)==0  % there is A+1
                                        CurrentAPosition=find(OperationSequencingList(:,4)==OperationA);
                                        CurrentAPosition=CurrentAPosition(1);
                                        CurrentAplus1Position=find(OperationSequencingList(:,4)==OperationA+1);
                                        CurrentAplus1Position=CurrentAplus1Position(1);
                                        
                                        if CurrentAPosition>CurrentAplus1Position
                                            % method: A+1 move to the position after A
                                            Auxiliary=OperationSequencingList(CurrentAplus1Position,:);
                                            OperationSequencingList(CurrentAplus1Position,:)=0;
                                            OperationSequencingList(CurrentAPosition+2:end+1,:)=OperationSequencingList(CurrentAPosition+1:end,:);
                                            OperationSequencingList(CurrentAPosition+1,:)=Auxiliary;
                                            OperationSequencingList(OperationSequencingList(:,1)==0,:)=[];
                                        end
                                    end
                                    
                                    %% check the position between B and B-1
                                    if numel(IndexB)==0  % there is B-1
                                        CurrentBPosition=find(OperationSequencingList(:,4)==OperationB);
                                        CurrentBPosition=CurrentBPosition(1);
                                        CurrentBminus1Position=find(OperationSequencingList(:,4)==OperationB-1);
                                        CurrentBminus1Position=CurrentBminus1Position(1);
                                        
                                        if CurrentBPosition<CurrentBminus1Position
                                            % method: B-1 move to the position before B
                                            Auxiliary=OperationSequencingList(CurrentBminus1Position,:);
                                            OperationSequencingList(CurrentBminus1Position,:)=0;
                                            OperationSequencingList(CurrentBPosition+1:end+1,:)=OperationSequencingList(CurrentBPosition:end,:);
                                            OperationSequencingList(CurrentBPosition,:)=Auxiliary; %%
                                            OperationSequencingList(OperationSequencingList(:,1)==0,:)=[];
                                        end
                                    end
  
                                    %% update other matrix
                                    solution_VNSNI1.OperationSequencingList=OperationSequencingList;
                                    
                                    solution_VNSNI1=GetScheduleFromOperationSequencingList (solution_VNSNI1,problemSet);
                                    
                                    solution_VNSNI1 = CreateMachinesSchedule(problemSet,solution_VNSNI1);
                                    
                                    solution_VNSNI1=RepresentationOfBestSolutionFromGEP(solution_VNSNI1,problemSet);
                                    
                                    solution_VNSNI1= CalculateObjectiveFunctions(problemSet,solution_VNSNI1);
                                    
%                                     if CheckWhetherFeasibleOfSolution(solution_VNSNI1.OperationSequencingList,problemSet)==0
%                                         disp('***')
%                                     end
                                    
                                end
                            end
                        end
                    end
                end
            end
            if Index==1 % success one move and break the loop
                break;
            end
        end
        if Index==1
            %% After this move, check from the first idel slot again
            Solution=solution_VNSNI1;
            
            OperationSequencingList=Solution.OperationSequencingList;
            operationsSchedule=Solution.operationsSchedule;
            IdlePositionOnMachine=Solution.IdlePositionOnMachine;
            ColumnMax=size(IdlePositionOnMachine,1);
%             CreateGanttDiagram(solution_VNSNI1,'AfterMove');
            break;
        else
            if j==MachineNum && l==ColumnMax
                TotalChecked=1;  % All idel slots have been checked and no improvement can be realized
            end
        end
    end
end

if Index==0
    solution_VNSNI1=Solution;
end
% CreateGanttDiagram(solution_VNSNI1,'AfterMove');

%% Get Solutions after right and left move
solutionV = GetSolutionAfterRLMove(solution_VNSNI1,problemSet);
end