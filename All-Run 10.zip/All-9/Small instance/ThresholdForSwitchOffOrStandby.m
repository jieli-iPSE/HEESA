function thresholdOfIdelTimeForMachines=ThresholdForSwitchOffOrStandby(problemSet)
machineNum=problemSet.problemSize.machinesNumber;

thresholdOfIdelTimeForMachines=zeros(machineNum,1);

for i=1:machineNum
    SwitchOffOnEnergy=cell2mat(problemSet.machinesSet(i,6));
    UnloadPower=cell2mat(problemSet.machinesSet(i,5));
    thresholdOfIdelTimeForMachines(i,1)=SwitchOffOnEnergy/UnloadPower;    
end
end