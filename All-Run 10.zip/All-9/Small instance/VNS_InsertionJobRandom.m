function solution_VNSIJR=VNS_InsertionJobRandom(solution,problemSet)
%%
solution=solution.solutionRightLiftMove;
% solution=RepresentationOfBestSolutionFromGEP(solution,problemSet);

%%
solution_VNSIJR.operationsSchedule=solution.operationsSchedule;
OperationSequencingList=solution.OperationSequencingList;

%%
JobNum=problemSet.problemSize.jobsNumber;

%% Select Two Jobs
Job1=0;
Job2=0;

while Job1==Job2 
    Job1=randperm(JobNum,1);
    Job2=randperm(JobNum,1);
    
    OperationNumOfJob1=cell2mat(problemSet.jobsSet(Job1,4));
    OperationNumOfJob2=cell2mat(problemSet.jobsSet(Job2,4));
end
%% insertion Job1 before Job2
for i=1:min(OperationNumOfJob1,OperationNumOfJob2)
    position1=find(OperationSequencingList(:,1)==Job1 & OperationSequencingList(:,2)==i);
    position2=find(OperationSequencingList(:,1)==Job2 & OperationSequencingList(:,2)==i);
    if position1>position2
        % forward insertion
        m=OperationSequencingList(position1,:);
        OperationSequencingList(position2+1:position1,:)=OperationSequencingList(position2:position1-1,:);
        OperationSequencingList(position2,:)=m;
    end
end

%%
solution_VNSIJR.OperationSequencingList=OperationSequencingList;

solution_VNSIJR= GetScheduleFromOperationSequencingList (solution_VNSIJR,problemSet);

solution_VNSIJR= CreateMachinesSchedule(problemSet,solution_VNSIJR);

solution_VNSIJR=RepresentationOfBestSolutionFromGEP(solution_VNSIJR,problemSet);

solution_VNSIJR= CalculateObjectiveFunctions(problemSet,solution_VNSIJR);

%%
solution_VNSIJR=GetSolutionAfterRLMove(solution_VNSIJR,problemSet);    
end