function solutionV=VNSEnergyGuidedSameMachineMoving2(solution,problemSet)

%% Moving of operations on the same machine is carried out based on the solution obtained from earliest starting strategy
%% idel time from one operation to another one (b+1), find the machine of operation B, one operation A is just before B, and swap A and B to reduce the duration of the idel by 
% note here, machine where swap occure and machine with idel slot are different

%%
Solution=solution.solutionEarliestStartingStrategy;

%%
% Solution is the schedule obtained based on earliest strategy and
% solution_VNSNI1 is the one after move
solution_VNSNI1.operationsSchedule=Solution.operationsSchedule;
OperationSequencingList=Solution.OperationSequencingList;
operationsSchedule=Solution.operationsSchedule;

%% Relevant data for the problem
MachineNum=problemSet.problemSize.machinesNumber;
JobNum=problemSet.problemSize.jobsNumber;
% OperationNum=problemSet.problemSize.totalOperationsNumber;
LastOperationsOfJobs=zeros(JobNum,1);
FirstOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
    FirstOperationsOfJobs(i,1) =  problemSet.jobsSet{i,5}(1);
    LastOperationsOfJobs(i,1)  =  problemSet.jobsSet{i,5}(end);
end

% threshold duration of idel time on machine for switch off/on energy or standby
% thresholdOfIdelTimeForMachines=ThresholdForSwitchOffOrStandby(problemSet);

%% conduct moving for all idel slots on all machines
%** Note after every move the operationsSchedule and machinesSchedule and IdlePositionOnMachine should be updated
IdlePositionOnMachine=Solution.IdlePositionOnMachine;
ColumnMax=size(Solution.IdlePositionOnMachine,1);
TotalChecked=0;
while TotalChecked==0
    Index=0;
    for j=1:MachineNum
        % idel time information is stored in the 2*i-1 and 2*i column
        for l=1:ColumnMax
            if cell2mat(IdlePositionOnMachine(l,2*j))==0 % the last operation in the machine j
                l=ColumnMax; %#ok<FXSET>
                break;
            end
            %             if cell2mat(IdlePositionOnMachine(l,2*j))~=cell2mat(IdlePositionOnMachine(min(l+1,ColumnMax),2*j-1))   %% there are one operation immediately after current operation
            if isempty(cell2mat(IdlePositionOnMachine(l,2*j)))==1
                l=ColumnMax; %#ok<FXSET>
                break;
            end
            AfterIdeloperationJobIndex=cell2mat(IdlePositionOnMachine(l,2*j));
            AfterIdeloperationPosition=find(OperationSequencingList(:,1)==AfterIdeloperationJobIndex(1) & OperationSequencingList(:,2)==AfterIdeloperationJobIndex(2));
            AfterIdeloperation=OperationSequencingList(AfterIdeloperationPosition(1),4);   % operation B+1
            
            
            Index1=find(FirstOperationsOfJobs==AfterIdeloperation);
            if numel(Index1)>0
                Index2=0; % (B+1) is first one of its belonging job
            else
                Index2=1; % (B+1) is not the first one of its belonging job
            end

            if Index2==1
                %% find the machine and operation A and B
                OperationB=AfterIdeloperation-1;
                machine=operationsSchedule(OperationB,7);
                OperationsOnThisMachine=cell2mat(Solution.machinesSchedule(machine,:));   % note this machine is different from j 
                LocationB=find(OperationsOnThisMachine==OperationB);
                
                if LocationB(1)~=1 
                    OperationA=OperationsOnThisMachine(LocationB(1)-1);
                    FinishTimeOfOperationA=operationsSchedule(OperationA,6);
                    StartTimeOfOperationA=operationsSchedule(OperationA,5);
                    StartTimeOfOperationB=operationsSchedule(OperationB,5);
                    if FinishTimeOfOperationA==StartTimeOfOperationB  % there is a operation immediately before the operation B                        
                        % GET Earliest starting timing of OperationB                         
                        % machine end time before operation A 
                        LocationA=LocationB(1)-1;
                        if LocationA==1
                            MachineEndTimeBeforeA=0;
                        else 
                            OperationBeforeA=OperationsOnThisMachine(LocationA-1);
                            MachineEndTimeBeforeA=operationsSchedule(OperationBeforeA,6);
                        end
                        % end time of B-1
                        IndexB=find(FirstOperationsOfJobs==OperationB);
                        if numel(IndexB)>0  % B is the first operation of its job 
                            EndTimeOfBminus1=0;
                        else 
                            EndTimeOfBminus1=operationsSchedule(OperationB-1,6);
                        end
                        if EndTimeOfBminus1<=StartTimeOfOperationA
                            StartTimeOfBAfterMove=max(MachineEndTimeBeforeA,EndTimeOfBminus1);
                            ProcessingTimeA=operationsSchedule(OperationA,6)-operationsSchedule(OperationA,5);
                            ProcessingTimeB=operationsSchedule(OperationB,6)-operationsSchedule(OperationB,5);
                            
                            EndTimeOfAAfterMove=StartTimeOfBAfterMove+ProcessingTimeA+ProcessingTimeB;
                            
                            % start time of A+1
                            IndexA=find(LastOperationsOfJobs==OperationA);
                            
                            if numel(IndexA)>0  % A is the last operation of its job
                                StartTimeOfAPlus1=inf;
                            else
                                StartTimeOfAPlus1=operationsSchedule(OperationA+1,5);
                            end
                            
                            if EndTimeOfAAfterMove<=StartTimeOfAPlus1
                                %% Swap A and B  % A is before B
                                PositionA=find(OperationSequencingList(:,4)==OperationA);
                                PositionB=find(OperationSequencingList(:,4)==OperationB);
                                
                                Auxiliary=OperationSequencingList(PositionA,:);
                                OperationSequencingList(PositionA,:)=OperationSequencingList(PositionB,:);
                                OperationSequencingList(PositionB,:)=Auxiliary;
                               
                                
                                %% check the position between A and A+1 
                                if numel(IndexA)==0  % there is A+1 
                                   CurrentAPosition=find(OperationSequencingList(:,4)==OperationA);
                                   CurrentAPosition=CurrentAPosition(1);
                                   CurrentAplus1Position=find(OperationSequencingList(:,4)==OperationA+1);
                                   CurrentAplus1Position=CurrentAplus1Position(1);
                                   
                                   if CurrentAPosition>CurrentAplus1Position
                                       % method: A+1 move to the position after A
                                       Auxiliary=OperationSequencingList(CurrentAplus1Position,:);
                                       OperationSequencingList(CurrentAplus1Position,:)=0;
                                       OperationSequencingList(CurrentAPosition+2:end+1,:)=OperationSequencingList(CurrentAPosition+1:end,:);
                                       OperationSequencingList(CurrentAPosition+1,:)=Auxiliary;
                                       OperationSequencingList(OperationSequencingList(:,1)==0,:)=[];
                                   end
                                end

                                %% check the position between B and B-1
                                if numel(IndexB)==0  % there is B-1
                                    CurrentBPosition=find(OperationSequencingList(:,4)==OperationB);
                                    CurrentBPosition=CurrentBPosition(1);
                                    CurrentBminus1Position=find(OperationSequencingList(:,4)==OperationB-1);
                                    CurrentBminus1Position=CurrentBminus1Position(1);
                                    
                                    if CurrentBPosition<CurrentBminus1Position
                                        % method: B-1 move to the position before B
                                        Auxiliary=OperationSequencingList(CurrentBminus1Position,:);
                                        OperationSequencingList(CurrentBminus1Position,:)=0;
                                        OperationSequencingList(CurrentBPosition+1:end+1,:)=OperationSequencingList(CurrentBPosition:end,:);
                                        OperationSequencingList(CurrentBPosition,:)=Auxiliary; %%
                                        OperationSequencingList(OperationSequencingList(:,1)==0,:)=[];
                                    end
                                end
                                                               
                                %% update other matrix
                                solution_VNSNI1.OperationSequencingList=OperationSequencingList;
                                
                                solution_VNSNI1=GetScheduleFromOperationSequencingList (solution_VNSNI1,problemSet);
                                
                                solution_VNSNI1 = CreateMachinesSchedule(problemSet,solution_VNSNI1);
                                
                                solution_VNSNI1=RepresentationOfBestSolutionFromGEP(solution_VNSNI1,problemSet);
                                
                                solution_VNSNI1= CalculateObjectiveFunctions(problemSet,solution_VNSNI1); 
                                
%                                 if CheckWhetherFeasibleOfSolution(solution_VNSNI1.OperationSequencingList,problemSet)==0
%                                     disp('***')
%                                 end
                            end
                        end
                    end
                end
            end
            %             end
            if Index==1 % success one move and break the loop
                break;
            end
        end
        if Index==1
            %% After this move, check from the first idel slot again
            Solution=solution_VNSNI1;
            
            OperationSequencingList=Solution.OperationSequencingList;
            operationsSchedule=Solution.operationsSchedule;
            IdlePositionOnMachine=Solution.IdlePositionOnMachine;
            ColumnMax=size(IdlePositionOnMachine,1);
%             CreateGanttDiagram(solution_VNSNI1,'AfterMove');
            break;
        else
            if j==MachineNum && l==ColumnMax
                TotalChecked=1;  % All idel slots have been checked and no improvement can be realized
            end
        end
    end
end

if Index==0
    solution_VNSNI1=Solution;
end
% CreateGanttDiagram(solution_VNSNI1,'AfterMove');



%% Get Solutions after right and left move
solutionV = GetSolutionAfterRLMove(solution_VNSNI1,problemSet);
end