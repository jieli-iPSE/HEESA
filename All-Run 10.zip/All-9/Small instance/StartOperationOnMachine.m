function [schedulingMatrics,solution] = StartOperationOnMachine(operation,machine,currentTime,processingTime,pc,schedulingMatrics,problemSet,solution)
    machineIndex=find(schedulingMatrics.freeMachines==machine);
    schedulingMatrics.freeMachines(machineIndex)=[];
    schedulingMatrics.recentlyStartedMachines(end+1)=machine;
    schedulingMatrics.machinesStartTimes(machine,1)=currentTime;
    schedulingMatrics.machinesStartTimes(machine,2)=currentTime+processingTime;
    %solution.operationsSchedule(operation,4)=currentTime;
    solution.operationsSchedule(operation,5)=currentTime;
    solution.operationsSchedule(operation,6)=currentTime+processingTime;
    solution.operationsSchedule(operation,7)=machine;
    solution.operationsSchedule(operation,8)=pc;
    
    NumberofopearionsonMachine=numel(solution.operationsSchedule(:,7),solution.operationsSchedule(:,7)==machine);
    
    solution.machinesStartTimes(machine,NumberofopearionsonMachine*2-1)=currentTime;
    solution.machinesStartTimes(machine,NumberofopearionsonMachine*2)=currentTime+processingTime;
    
    schedulingMatrics.nextEventsList(end+1,1)=currentTime+processingTime;
    schedulingMatrics.nextEventsList(end,2)=2;
    schedulingMatrics.nextEventsList(end,3)=operation;
    operationRelatedJob=cell2mat(problemSet.operationsSet(operation,2));
    orderInJob=cell2mat(problemSet.operationsSet(operation,3));
    relatedJobOperationNumber=cell2mat(problemSet.jobsSet(operationRelatedJob,4));
    if relatedJobOperationNumber > orderInJob
        schedulingMatrics.nextEventsList(end+1,1)=currentTime+processingTime;
        schedulingMatrics.nextEventsList(end,2)=1;
        schedulingMatrics.nextEventsList(end,3)=operation+1;
        
        solution.operationsSchedule(operation+1,4)=currentTime+processingTime;
    end
    schedulingMatrics.nextEventsList(end+1,1)=currentTime+processingTime;
    schedulingMatrics.nextEventsList(end,2)=3;
    schedulingMatrics.nextEventsList(end,3)=machine;


end

