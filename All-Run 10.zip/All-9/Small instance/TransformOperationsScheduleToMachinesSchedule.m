function [solution] = TransformOperationsScheduleToMachinesSchedule(problemSet,solution)
    
    %[problemSet] = FJSSPReadProblemSet(benchmark);
    solution.machinesSchedule=cell(problemSet.problemSize.machinesNumber,1);
    for i=1:problemSet.problemSize.totalOperationsNumber
        operation=solution.operationsSchedule(i,1);
        machine=solution.operationsSchedule(i,7);
        index=numel(solution.machinesSchedule{machine,1})+1;
        solution.machinesSchedule{machine,1}(index)=operation;
        %problemSet.machinesSchedule{machine,2}=[problemSet.machinesSchedule{machine,2} operation];
    end
    for i=1:problemSet.problemSize.machinesNumber
        operations=cell2mat(solution.machinesSchedule(i,1));
        processingTimes=zeros(1,numel(operations));
        for j=1:numel(operations)
            operation=operations(1,j);
            processingTimes(1,j)=solution.operationsSchedule(operation,5);
        end
        [~,indexes]=sort(processingTimes);
        operations=operations(indexes);
        %problemSet.machinesSchedule(i,1)=mat2cell(operations);
        solution.machinesSchedule(i,1)={operations};
    end

end

