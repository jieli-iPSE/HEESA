$gdxin matdata.gdx
$gdxin
