function solution_VNOSR=VNS_OperationInsertionBackwardOnMachineRandom(solution,problemSet)

%%
% solution=RepresentationOfBestSolutionFromGEP(solution,problemSet);
solution=solution.solutionRightLiftMove;

%%
OperationNum=problemSet.problemSize.totalOperationsNumber;
JobNum=problemSet.problemSize.jobsNumber;
MachineNum=problemSet.problemSize.machinesNumber;

LastOperationsOfJobs=zeros(JobNum,1);
FirstOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
    FirstOperationsOfJobs(i,1)= problemSet.jobsSet{i,5}(1);
    LastOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(end);
end

%%
OperationSequencingList=solution.OperationSequencingList;

%% Select One machine
OperationsNumOnMachine=zeros(1,MachineNum);
for i=1:MachineNum
    OperationsNumOnMachine(1,i)=numel(solution.operationsSchedule(:,7)==i); %#ok<SZARLOG>
end
MachineSet=find(OperationsNumOnMachine(1,:)>1);
if numel(MachineSet)>0
    SelectedMachine=MachineSet(randperm(numel(MachineSet),1));
    %% Operations On this Machine
    OperationsOnSelectMachine=zeros(1,OperationNum);
    for i=1:OperationNum
        if solution.operationsSchedule(i,7)==SelectedMachine
            OperationsOnSelectMachine(1,i)=1;
        end
    end
    OperationsSet=find(OperationsOnSelectMachine==1);
    if numel(OperationsSet)>1
    %% Select two operatios going to be swapped
    i=1;
    while i<=(numel(OperationsSet)*(numel(OperationsSet)-1)/2)
        OperationInsertion=OperationsSet(randperm(numel(OperationsSet),2));
        if solution.operationsSchedule(OperationInsertion(1),2)==solution.operationsSchedule(OperationInsertion(2),2)  % two selected operations belonging to same job
            i=i+1;
        else
            break;
        end
    end
    if solution.operationsSchedule(OperationInsertion(1),2)~=solution.operationsSchedule(OperationInsertion(2),2)
        LocationsOfOperationInsertion=zeros(1,2);
        LocationsOfOperationInsertion(1)=find(solution.OperationSequencingList(:,4)==OperationInsertion(1));
        LocationsOfOperationInsertion(2)=find(solution.OperationSequencingList(:,4)==OperationInsertion(2));
        if LocationsOfOperationInsertion(1)<LocationsOfOperationInsertion(2)
            operation1=OperationInsertion(1);
%             operation2=OperationSwap(2);
            LocationOfOperation1BeforeInsertion=LocationsOfOperationInsertion(1);
            LocationOfOperation2BeforeInsertion=LocationsOfOperationInsertion(2);
        else
%             operation2=OperationSwap(1);
            operation1=OperationInsertion(2);
            LocationOfOperation2BeforeInsertion=LocationsOfOperationInsertion(1);
            LocationOfOperation1BeforeInsertion=LocationsOfOperationInsertion(2);
        end
        %% Swap  operation1 backward operation2 forward
        Index=find(LastOperationsOfJobs==operation1);
        if numel(Index)>0   % operation is the last operation of one job
            LocationOfNextOperation1OfSameJob=OperationNum+1;
        else
            LocationOfNextOperation1OfSameJob=find(solution.OperationSequencingList(:,4)==operation1+1);
        end
        OperationSequencingList(LocationOfOperation1BeforeInsertion:LocationOfOperation2BeforeInsertion-1,:)=solution.OperationSequencingList(LocationOfOperation1BeforeInsertion+1:LocationOfOperation2BeforeInsertion,:);
        OperationSequencingList(LocationOfOperation2BeforeInsertion,:)=solution.OperationSequencingList(LocationOfOperation1BeforeInsertion,:);
        
        
        %% check feasiblility from
        Auxiliary=[];
        if LocationOfNextOperation1OfSameJob<LocationOfOperation2BeforeInsertion 
            LocationOfNextOperation1OfSameJob=find(OperationSequencingList(:,4)==operation1+1);
            for i=LocationOfNextOperation1OfSameJob:LocationOfOperation2BeforeInsertion-1
                if OperationSequencingList(i,1)==OperationSequencingList(LocationOfOperation2BeforeInsertion,1)
                    Auxiliary(end+1,:)=OperationSequencingList(i,:); %#ok<AGROW>
                    OperationSequencingList(i,:)=0;
                end
            end
            Add=size(Auxiliary,1);
            OperationSequencingList((LocationOfOperation2BeforeInsertion+1+Add):(OperationNum+Add),:)=OperationSequencingList((LocationOfOperation2BeforeInsertion+1):(OperationNum),:);
            OperationSequencingList((LocationOfOperation2BeforeInsertion+1):(LocationOfOperation2BeforeInsertion+Add),:)=Auxiliary;
        end
 
        OperationSequencingList(OperationSequencingList(:,1)==0,:)=[];
        
        solution_VNOSR.operationsSchedule=solution.operationsSchedule;
        
        %%
        solution_VNOSR.OperationSequencingList=OperationSequencingList;
        
        solution_VNOSR=GetScheduleFromOperationSequencingList (solution_VNOSR,problemSet);
        
        solution_VNOSR = CreateMachinesSchedule(problemSet,solution_VNOSR);
        
        solution_VNOSR=RepresentationOfBestSolutionFromGEP(solution_VNOSR,problemSet);
        
        solution_VNOSR= CalculateObjectiveFunctions(problemSet,solution_VNOSR);

    else % No swap
        solution_VNOSR=solution;
    end
    else
        solution_VNOSR=solution;
    end
else    % No swap
    solution_VNOSR=solution;
end

%%
solution_VNOSR=GetSolutionAfterRLMove(solution_VNOSR,problemSet);
end