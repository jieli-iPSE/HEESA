function solution_VNSMFTG=VNS_MachineMutationFinishTimeGuided(solution,problemSet)
%%
solution=solution.solutionRightLiftMove;

%%
OperationNum=problemSet.problemSize.totalOperationsNumber;
OperationSet=problemSet.operationsSet;
JobNum=problemSet.problemSize.jobsNumber;
% MachineNum=problemSet.problemSize.machinesNumber;

%% Select Machine with Maximum complete time
% FinishTimeOfMachines=FinishTimeOnMachine(solution,problemSet);
CompleteTimeOfMachines=MakespanOnMachine(solution,problemSet);

%% Only find the machine with maximum complete time, if there is no operation can be moved to other machine, ternimate the search
Trytime=1;
% for Trytime=1:MachineNum
    SelectedMachine=CompleteTimeOfMachines(Trytime,1);
    %% Operation Set: operation performed on selected machine and have another optional machine
    Operations_PerformedOnSelectedMachine_HavingOtherMachine=zeros(1,OperationNum);
    for i=1:OperationNum
        if cell2mat(OperationSet(i,4))>1  %% with multiple avaiable machine
            if solution.operationsSchedule(i,7)==SelectedMachine  %% Current performed on the Selected machine
                Operations_PerformedOnSelectedMachine_HavingOtherMachine(1,i)=1;
            end
        end
    end
    OperationsSet=find(Operations_PerformedOnSelectedMachine_HavingOtherMachine==1);
%     if isempty(OperationsSet)==0
%         break;
%     end
% end


if  isempty(OperationsSet)==0
    operation=OperationsSet(randperm(numel(OperationsSet),1));
    %% Machine After Mutation
    MachineSetOfOperation=cell2mat(OperationSet(operation,5));
    i=1;
    while i<=numel(MachineSetOfOperation)
        if MachineSetOfOperation(i)==SelectedMachine
            MachineSetOfOperation(i)=[];
            i=i-1;
        end
        i=i+1;
    end
    
    MachineAfterMutation=MachineSetOfOperation(randperm(numel(MachineSetOfOperation),1));
    
    %% Determine the position of Operation on the MachineAfterMutation
    LastOperationsOfJobs=zeros(JobNum,1);
    FirstOperationsOfJobs=zeros(JobNum,1);
    for i=1:JobNum
          FirstOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(1);
        LastOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(end);
    end
    % start time of operation +1
    LocationOfOperationBeforeMutation=find(solution.OperationSequencingList(:,4)==operation);
    Index=find(LastOperationsOfJobs==operation);
    
    if numel(Index)>0   % operation is the last operation of one job
        %     StarttimeOfNextOperation=CompleteTimeOfMachines(1,2);
        LocationOfOperationAfterMutation=OperationNum;
    else
        StarttimeOfNextOperation=solution.operationsSchedule(operation+1,5);
        LocationOfNextOperation=find(solution.OperationSequencingList(:,4)==operation+1);
        OperationsOnMachineAfterMutation=find(solution.operationsSchedule(:,7)==MachineAfterMutation)';
        StartTimesOnMachineAfterMutation=zeros(1,numel(OperationsOnMachineAfterMutation));
        for i=1:numel(OperationsOnMachineAfterMutation)
            OperationNow=OperationsOnMachineAfterMutation(i);
            StartTimesOnMachineAfterMutation(1,i)=solution.operationsSchedule(OperationNow,5);
        end
        
        InsertBeforeStartTime=max(StartTimesOnMachineAfterMutation(StartTimesOnMachineAfterMutation(1,:)<=StarttimeOfNextOperation));
        
        if numel(InsertBeforeStartTime)>0
            
            InsertBeforeOperationIndex=OperationsOnMachineAfterMutation(StartTimesOnMachineAfterMutation(1,:)==InsertBeforeStartTime);
            
            EndTimeOfInsertBeforeOperationIndex=solution.operationsSchedule(InsertBeforeOperationIndex,6);
            
            if EndTimeOfInsertBeforeOperationIndex> StarttimeOfNextOperation
                LocationOfOperationAfterMutation=max(find(solution.OperationSequencingList(:,4)==InsertBeforeOperationIndex)-1,1);

            else
                LocationOfOperationAfterMutation=min(find(solution.OperationSequencingList(:,4)==InsertBeforeOperationIndex)+1,OperationNum);
%                 LocationOfOperationAfterMutation=min(LocationOfOperationAfterMutation,LocationOfNextOperation-1);
            end
            LocationOfOperationAfterMutation=min(LocationOfOperationAfterMutation,LocationOfNextOperation-1);
            index=find(FirstOperationsOfJobs==operation);
            if numel(index)==0
                LocationOfPreviousOperation=find(solution.OperationSequencingList(:,4)==operation-1);
                LocationOfOperationAfterMutation=max(LocationOfOperationAfterMutation,LocationOfPreviousOperation+1);
            end
        else
            LocationOfOperationAfterMutation=LocationOfOperationBeforeMutation;
        end
        
    end
    
    %% Mutation and changing position of Operation in OperationSequenceList
    OperationSequencingList=solution.OperationSequencingList;
    Auxiliary=solution.OperationSequencingList(LocationOfOperationBeforeMutation,:);
    
    Auxiliary(1,3)=MachineAfterMutation;
    if LocationOfOperationAfterMutation>LocationOfOperationBeforeMutation
 
        OperationSequencingList(LocationOfOperationBeforeMutation:LocationOfOperationAfterMutation-1,:)=solution.OperationSequencingList(LocationOfOperationBeforeMutation+1:LocationOfOperationAfterMutation,:); 
    else
        if LocationOfOperationAfterMutation<LocationOfOperationBeforeMutation
            
            OperationSequencingList(LocationOfOperationAfterMutation+1:LocationOfOperationBeforeMutation,:)=solution.OperationSequencingList(LocationOfOperationAfterMutation:LocationOfOperationBeforeMutation-1,:); 
        end
    end
    OperationSequencingList(LocationOfOperationAfterMutation,:)=Auxiliary;
    
    %%
    solution_VNSMFTG.OperationSequencingList=OperationSequencingList;
    
    % Update operationsSchedule
     MachineSetOfOperation=cell2mat(OperationSet(operation,5));
     
    solution_VNSMFTG.operationsSchedule=solution.operationsSchedule;
    
    CuttingPowerSet=cell2mat(OperationSet(operation,8));
    
    IndexofMachine=find(MachineSetOfOperation==MachineAfterMutation);
    
    CuttingpowerofOperation=CuttingPowerSet(1,IndexofMachine(1));
    
    solution_VNSMFTG.operationsSchedule(operation,7)=MachineAfterMutation;
    
    solution_VNSMFTG.operationsSchedule(operation,8)=CuttingpowerofOperation;
    
    solution_VNSMFTG =GetScheduleFromOperationSequencingList(solution_VNSMFTG ,problemSet);
    
    solution_VNSMFTG = CreateMachinesSchedule(problemSet,solution_VNSMFTG);
    
    solution_VNSMFTG=RepresentationOfBestSolutionFromGEP(solution_VNSMFTG,problemSet);
    
    solution_VNSMFTG = CalculateObjectiveFunctions(problemSet,solution_VNSMFTG);
else
    solution_VNSMFTG=solution;
end

%%
solution_VNSMFTG=GetSolutionAfterRLMove(solution_VNSMFTG,problemSet);
end