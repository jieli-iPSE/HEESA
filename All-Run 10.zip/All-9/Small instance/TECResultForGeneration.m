function TEC=TECResultForGeneration(pop,nPop)
    TEC.MinResult=pop{1}.obj;
    TEC.MaxResult=pop{end}.obj;
    TEC.AverageResult=0;
    tec=zeros(nPop,1);
     for i=1:nPop
         tec(i)=pop{i}.obj; 
     end

    TEC.AverageResult=sum(tec)/nPop;
end