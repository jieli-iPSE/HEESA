function solution=shaking(solution,problemSet,Mmax,KnowledgeBaseMachine)
n=randperm((Mmax),1);

if n==1 
    solution=VNS_MachineMutationKnowledgeGuided(solution,problemSet,KnowledgeBaseMachine);
end

if n==2
    solution=VNS_InsertionJobRandom(solution,problemSet);
end

if n==3
    solution=VNS_ExchangeJobRandom(solution,problemSet);
end

end