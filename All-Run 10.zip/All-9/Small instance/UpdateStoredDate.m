function [BestIndividulStored,ObjsStored]=UpdateStoredDate(pop,BestIndividulStored,ObjsStored)
Num=size(ObjsStored,1);

for i=1:Num
    %% find
    Index=find(ObjsStored(:,1)==pop{i}.obj);
    if numel(Index)==0
        Worst=max(ObjsStored);
        WorstLocation=find(ObjsStored(:,1)==Worst);
        if pop{i}.obj<Worst
            ObjsStored(WorstLocation(1),1)=pop{i}.obj;
            BestIndividulStored{WorstLocation(1)}=pop{i};
        end
    end
end
end

