function priority=calculatePriorityMultiGene(it,nr,pt,pc,pu,Chromosome,LastRow,LeftRight,GeneNumber)
%Variable: 1:it idle time, 2: pt  processing time, 3: pc cutting power, 4: pu unload power 5: nr unschuduled opearion
% Operation: 1: + 2: - 3:/ 4: * 5:Q
CalculatedResult=zeros(5,1);   %% Current code can address chromosome with maximum 5 genes
for gene=1:GeneNumber
    lastRow=LastRow{gene};
    leftRight=LeftRight{gene};
    chromosome=Chromosome{gene};
    for i=lastRow:-1:1
        if leftRight(i,1)==0
            leftRight(i,6)= chromosome(1,i);
            continue;
        end
        leftRight2=leftRight(i,2);
        leftRight3=leftRight(i,3);
        
        if leftRight2 > lastRow
            elementInChromosome=chromosome(1,leftRight2);
            if leftRight(i,1)==0
                elementInChromosome=chromosome(1,i);
            end
            if elementInChromosome==1
                leftRight4=it;
            elseif elementInChromosome==2
                leftRight4=pt;
            elseif elementInChromosome==3
                leftRight4=pc;
            elseif elementInChromosome==4
                leftRight4=pu;
            elseif elementInChromosome==5
                leftRight4=nr;
            end
            leftRight(i,4)=leftRight4;
        else
            if leftRight(leftRight2,1)==0
                elementInChromosome= leftRight(leftRight2,6);
                if elementInChromosome==1
                    leftRight4=it;
                elseif elementInChromosome==2
                    leftRight4=pt;
                elseif elementInChromosome==3
                    leftRight4=pc;
                elseif elementInChromosome==4
                    leftRight4=pu;
                elseif elementInChromosome==5
                    leftRight4=nr;
                end
            else
                leftRight4=leftRight(leftRight2,6);
            end
            leftRight(i,4)=leftRight4;
        end
        
        if leftRight(i,1)~=0 && leftRight(i,1)~=5
            if leftRight3 > lastRow
                elementInChromosome=chromosome(1,leftRight3);
                if elementInChromosome==1
                    leftRight5=it;
                elseif elementInChromosome==2
                    leftRight5=pt;
                elseif elementInChromosome==3
                    leftRight5=pc;
                elseif elementInChromosome==4
                    leftRight5=pu;
                elseif elementInChromosome==5
                    leftRight5=nr;
                end
                leftRight(i,5)=leftRight5;
            else
                if leftRight(leftRight3,1)==0
                    elementInChromosome= leftRight(leftRight3,6);
                    if elementInChromosome==1
                        leftRight5=it;
                    elseif elementInChromosome==2
                        leftRight5=pt;
                    elseif elementInChromosome==3
                        leftRight5=pc;
                    elseif elementInChromosome==4
                        leftRight5=pu;
                    elseif elementInChromosome==5
                        leftRight5=nr;
                    end
                else
                    leftRight5=leftRight(leftRight3,6);
                end
                leftRight(i,5)=leftRight5;
            end
        end
        
        operator=leftRight(i,1);
        if operator==1
            leftRight(i,6)=leftRight4+leftRight5;
        elseif operator==2
            leftRight(i,6)=leftRight4-leftRight5;
        elseif operator==3
            leftRight(i,6)=leftRight4/leftRight5;
        elseif operator==4
            leftRight(i,6)=leftRight4*leftRight5;
        elseif operator==5
            leftRight(i,6)=leftRight4^(1/2);
        end
    end
    CalculatedResult(gene)=leftRight(1,6);
end

lastRow=LastRow{GeneNumber+1};
leftRight=LeftRight{GeneNumber+1};
chromosome=Chromosome{GeneNumber+1};
for i=lastRow:-1:1
    if leftRight(i,1)==0
        leftRight(i,6)= chromosome(1,i);
        continue;
    end
    leftRight2=leftRight(i,2);
    leftRight3=leftRight(i,3);
    
    if leftRight2 > lastRow
        elementInChromosome=chromosome(1,leftRight2);
        if leftRight(i,1)==0
            elementInChromosome=chromosome(1,i);
        end
        if elementInChromosome==1
            leftRight4=CalculatedResult(1);
        elseif elementInChromosome==2
            leftRight4=CalculatedResult(2);
        elseif elementInChromosome==3
            leftRight4=CalculatedResult(3);
        elseif elementInChromosome==4
            leftRight4=CalculatedResult(4);
        elseif elementInChromosome==5
            leftRight4=CalculatedResult(5);
        end
        leftRight(i,4)=leftRight4;
    else
        if leftRight(leftRight2,1)==0
            elementInChromosome= leftRight(leftRight2,6);
            if elementInChromosome==1
                leftRight4=CalculatedResult(1);
            elseif elementInChromosome==2
                leftRight4=CalculatedResult(2);
            elseif elementInChromosome==3
                leftRight4=CalculatedResult(3);
            elseif elementInChromosome==4
                leftRight4=CalculatedResult(4);
            elseif elementInChromosome==5
                leftRight4=CalculatedResult(5);
            end
        else
            leftRight4=leftRight(leftRight2,6);
        end
        leftRight(i,4)=leftRight4;
    end
    
    if leftRight(i,1)~=0 && leftRight(i,1)~=5
        if leftRight3 > lastRow
            elementInChromosome=chromosome(1,leftRight3);
            if elementInChromosome==1
                leftRight5=CalculatedResult(1);
            elseif elementInChromosome==2
                leftRight5=CalculatedResult(2);
            elseif elementInChromosome==3
                leftRight5=CalculatedResult(3);
            elseif elementInChromosome==4
                leftRight5=CalculatedResult(4);
            elseif elementInChromosome==5
                leftRight5=CalculatedResult(5);
            end
            leftRight(i,5)=leftRight5;
        else
            if leftRight(leftRight3,1)==0
                elementInChromosome= leftRight(leftRight3,6);
                if elementInChromosome==1
                    leftRight5=CalculatedResult(1);
                elseif elementInChromosome==2
                    leftRight5=CalculatedResult(2);
                elseif elementInChromosome==3
                    leftRight5=CalculatedResult(3);
                elseif elementInChromosome==4
                    leftRight5=CalculatedResult(4);
                elseif elementInChromosome==5
                    leftRight5=CalculatedResult(5);
                end
            else
                leftRight5=leftRight(leftRight3,6);
            end
            leftRight(i,5)=leftRight5;
        end
    end
    
    operator=leftRight(i,1);
    if operator==1
        leftRight(i,6)=leftRight4+leftRight5;
    elseif operator==2
        leftRight(i,6)=leftRight4-leftRight5;
    elseif operator==3
        leftRight(i,6)=leftRight4/leftRight5;
    elseif operator==4
        leftRight(i,6)=leftRight4*leftRight5;
    elseif operator==5
        leftRight(i,6)=leftRight4^(1/2);
    end
end
priority=leftRight(1,6);

end