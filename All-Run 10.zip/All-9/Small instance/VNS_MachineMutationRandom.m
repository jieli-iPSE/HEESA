function solution_VNSMMR=VNS_MachineMutationRandom(solution,problemSet)

%%
solution=solution.solutionRightLiftMove;
% solution=RepresentationOfBestSolutionFromGEP(solution,problemSet);

%%
OperationSet=problemSet.operationsSet;
OperationNum=problemSet.problemSize.totalOperationsNumber;
JobNum=problemSet.problemSize.jobsNumber;
% MachineNum=problemSet.problemSize.machinesNumber;

LastOperationsOfJobs=zeros(JobNum,1);
FirstOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
    FirstOperationsOfJobs(i,1)= problemSet.jobsSet{i,5}(1);
    LastOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(end);
end

%% Operations with multiple optional machines-----OperationsSet
OperationsWithMultipleUnitsBinary=zeros(1,OperationNum);

for i=1:OperationNum
    if cell2mat(OperationSet(i,4))>1  %% with multiple avaiable machine
            OperationsWithMultipleUnitsBinary(1,i)=1;
    end
end
OperationsSet=find(OperationsWithMultipleUnitsBinary==1);

%% 
OperationSequencingList=solution.OperationSequencingList;

if numel(OperationsSet)>0 
    %% Randomly Select One operation in OperationsSet
     operation=OperationsSet(randperm(numel(OperationsSet),1));
     %% Machines for the selected operation
      MachineBeforeMutation=solution.operationsSchedule(operation,7);
      MachineSetOfOperation=cell2mat(OperationSet(operation,5));
      i=1;
      while i<=numel(MachineSetOfOperation)
          if MachineSetOfOperation(i)==MachineBeforeMutation
              MachineSetOfOperation(i)=[];
              i=i-1;
          end
          i=i+1;
      end
      MachineAfterMutation=MachineSetOfOperation(randperm(numel(MachineSetOfOperation),1));

      %% Determine position of the selected operation on machine after mutation 
      Index=find(LastOperationsOfJobs==operation);
      if numel(Index)>0   % operation is the last operation of one job
          LocationOfNextOperationOfSameJob=OperationNum+1;
      else 
          LocationOfNextOperationOfSameJob=find(solution.OperationSequencingList(:,4)==operation+1);
      end
      Index=find(FirstOperationsOfJobs==operation);
      if numel(Index)>0   % operation is the first operation of one job
          LocationOfPreviousOperationOfSameJob=0;
      else 
          LocationOfPreviousOperationOfSameJob=find(solution.OperationSequencingList(:,4)==operation-1);
      end      
      % Acceptable range for the selected operation on the machine afte mutation is (LocationOfPreviousOperationOfSameJob,LocationOfNextOperationOfSameJob)
      OperationsInAcceptableRange=zeros(1,OperationNum);
      for i=1:OperationNum
          PositionOfI=find(solution.OperationSequencingList(:,4)==i);
          if solution.operationsSchedule(i,7)==MachineAfterMutation
              if PositionOfI>LocationOfPreviousOperationOfSameJob
                  if PositionOfI<LocationOfNextOperationOfSameJob
                      OperationsInAcceptableRange(1,i)=1;
                  end
              end
          end
      end
      OperationsSetInAcceptableRangeOnMachineAfterMutation=find(OperationsInAcceptableRange==1);
      LocationOfOperationBeforeMutation=find(solution.OperationSequencingList(:,4)==operation);
      Auxiliary=solution.OperationSequencingList(LocationOfOperationBeforeMutation,:);
      Auxiliary(1,3)=MachineAfterMutation;
      if numel( OperationsSetInAcceptableRangeOnMachineAfterMutation)>0
          OperationInsertBefore=OperationsSetInAcceptableRangeOnMachineAfterMutation(randperm(numel(OperationsSetInAcceptableRangeOnMachineAfterMutation),1));
          LocationOperationInsertBefore=find(solution.OperationSequencingList(:,4)==OperationInsertBefore);
          
          if LocationOperationInsertBefore<LocationOfOperationBeforeMutation
              LocationOfOperationAfterMutation=LocationOperationInsertBefore;
              OperationSequencingList(LocationOfOperationAfterMutation+1:LocationOfOperationBeforeMutation,:)=solution.OperationSequencingList(LocationOfOperationAfterMutation:LocationOfOperationBeforeMutation-1,:);
          else
              if  LocationOperationInsertBefore>LocationOfOperationBeforeMutation
                  LocationOfOperationAfterMutation=LocationOperationInsertBefore-1;
                  OperationSequencingList(LocationOfOperationBeforeMutation:LocationOfOperationAfterMutation-1,:)=solution.OperationSequencingList(LocationOfOperationBeforeMutation+1:LocationOfOperationAfterMutation,:);
              end
          end
      else 
          LocationOfOperationAfterMutation=LocationOfOperationBeforeMutation;
      end
      OperationSequencingList(LocationOfOperationAfterMutation,:)=Auxiliary;
      
      %%
      solution_VNSMMR.OperationSequencingList=OperationSequencingList;
      % Update operationsSchedule
      MachineSetOfOperation=cell2mat(OperationSet(operation,5));
      
      solution_VNSMMR.operationsSchedule=solution.operationsSchedule;
      
      CuttingPowerSet=cell2mat(OperationSet(operation,8));
      
      IndexofMachine=find(MachineSetOfOperation==MachineAfterMutation);
      
      CuttingpowerofOperation=CuttingPowerSet(1,IndexofMachine(1));
      
      solution_VNSMMR.operationsSchedule(operation,7)=MachineAfterMutation;
      
      solution_VNSMMR.operationsSchedule(operation,8)=CuttingpowerofOperation;
      
      solution_VNSMMR =GetScheduleFromOperationSequencingList(solution_VNSMMR ,problemSet);
      
      solution_VNSMMR = CreateMachinesSchedule(problemSet,solution_VNSMMR);
      
      solution_VNSMMR=RepresentationOfBestSolutionFromGEP(solution_VNSMMR,problemSet);
      
      solution_VNSMMR = CalculateObjectiveFunctions(problemSet,solution_VNSMMR);
else   % Assignment for all operations would not be changed
solution_VNSMMR=solution; 
end

%%
solution_VNSMMR=GetSolutionAfterRLMove(solution_VNSMMR,problemSet);   
end