function solutionV=VNSEnergyGuidedCrossMachineMoving(solution,problemSet)

%% Find the idle slots on machine and find operations on other machines to fill it, the selected operation is decided based on the effect after move rather than other criteria 
%% Idel before the first operation and after the last operation on one machine are negelected
%% Moving is conducted on the solution after lift/right move

%%
Solution=solution.solutionRightLiftMove;

%%
% solution_VNSNI1 is the one after move
solution_VNSNI1.operationsSchedule=Solution.operationsSchedule;

%% Relevant data for the problem
MachineNum=problemSet.problemSize.machinesNumber;
JobNum=problemSet.problemSize.jobsNumber;
OperationNum=problemSet.problemSize.totalOperationsNumber;

LastOperationsOfJobs=zeros(JobNum,1);
FirstOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
    FirstOperationsOfJobs(i,1) =  problemSet.jobsSet{i,5}(1);
    LastOperationsOfJobs(i,1)  =  problemSet.jobsSet{i,5}(end);
end

operationsSet=problemSet.operationsSet;
machinesSet=problemSet.machinesSet;
% threshold duration of idel time on machine for switch off/on energy or standby
thresholdOfIdelTimeForMachines=ThresholdForSwitchOffOrStandby(problemSet);

%% conduct moving for all idel slots on all machines
%** Note after every move the operationsSchedule and machinesSchedule and IdlePositionOnMachine should be updated

TotalChecked=0;
while TotalChecked==0

    OperationSequencingList=Solution.OperationSequencingList;
    operationsSchedule=Solution.operationsSchedule;
    machinesSchedule=Solution.machinesSchedule;
    IdlePositionOnMachine=Solution.IdlePositionOnMachine;
    ColumnMax=size(Solution.IdlePositionOnMachine,1);
    
    Index=0;
    for j=1:MachineNum
        % idel time information is stored in the 2*i-1 and 2*i column
        
        for l=2:ColumnMax   % the idel before the first operation is not considerred
            if cell2mat(IdlePositionOnMachine(l,2*j))==0     % the last operation in the machine j
                l=ColumnMax; %#ok<FXSET>
                break;
            end

            if isempty(cell2mat(IdlePositionOnMachine(l,2*j)))==1
                l=ColumnMax; %#ok<FXSET>
                break;
            end
            %% calculate the timing for the idel slot on current machine j
            BeforeIdleoperationJobIndex=cell2mat(IdlePositionOnMachine(l,2*j-1));
            AfterIdleoperationJobIndex=cell2mat(IdlePositionOnMachine(l,2*j));
            BeforeIdleOperationPosition=find(OperationSequencingList(:,1)==BeforeIdleoperationJobIndex(1) & OperationSequencingList(:,2)==BeforeIdleoperationJobIndex(2));
            AfterIdleOperationPosition=find(OperationSequencingList(:,1)==AfterIdleoperationJobIndex(1) & OperationSequencingList(:,2)==AfterIdleoperationJobIndex(2));
            BeforeIdleOperation=OperationSequencingList(BeforeIdleOperationPosition(1),4);
            AfterIdleOperation=OperationSequencingList(AfterIdleOperationPosition(1),4);
            
            % idel slot is represented by S 
            StartTS=operationsSchedule(BeforeIdleOperation,6);   % start time of idel is the ending of operation before it              
            EndTS=operationsSchedule(AfterIdleOperation,5);
            DurS=EndTS-StartTS;
            
            %% find operations can be performed on j but currently not  (saved in OperationsSet)
            OperationsSet=zeros(1,OperationNum);
            for i=1:OperationNum
                if cell2mat(operationsSet(i,4))>1  %% with multiple avaiable machine
                    if Solution.operationsSchedule(i,7)~=j  %% Current not performed on the Selected machine
                        if isempty(find(cell2mat(operationsSet(i,5))==j, 1))==0   % not empty, it means j is one of the available machine for i
                            OperationsSet(1,i)=1;
                        end
                    end
                end
            end
            
            OperationsSet=find(OperationsSet==1,1);   
            
            if numel(OperationsSet)>0
                %% check processing time, if the processing time for one operation A is larger than the duration of idel s, saved in operationsSet
                % Get the processing time and cutting power for operations in the OperationsSet on j
                PTOperationsSet=zeros(1,size(OperationsSet,2));
                PCOperationsSet=zeros(1,size(OperationsSet,2));
                for i=1:size(OperationsSet,2)
                    operation=OperationsSet(i);
                    MachinesSet=cell2mat(operationsSet(operation,5));
                    OperationsTimeSet=cell2mat(operationsSet(operation,6));
                    CuttingPowerSet=cell2mat(operationsSet(operation,8));
                    Index1=find(MachinesSet==j);
                    PTOperationsSet(i)=OperationsTimeSet(Index1(1));
                    PCOperationsSet(i)=CuttingPowerSet(Index1(1));
                end
                
                i=1;
                while i<=size(OperationsSet,2)
                    if DurS<PTOperationsSet(i)
                        OperationsSet(i)=[];
                        PTOperationsSet(i)=[];
                        PCOperationsSet(i)=[];
                        i=i-1;
                    else
                        if DurS-PTOperationsSet(i)>=thresholdOfIdelTimeForMachines(j)   % this means the move cannot lead to reduction of energy on j
                            OperationsSet(i)=[];
                            PTOperationsSet(i)=[];
                            PCOperationsSet(i)=[];
                            i=i-1;
                        end
                    end
                    i=i+1;
                end
                
                % Currently, Operations in the OperationsSet would be potential to be interted into the idel slot
                if numel(OperationsSet)>0
                    i=1;
                    while i<=size(OperationsSet,2)   % A is operation i
                        % check their earliest starting time (EndTimeAminus1) and latest ending time(StartTimeAplus1)
                        operation=OperationsSet(i);
                        
                        % A-1 end time
                        Index1=find(FirstOperationsOfJobs==operation);
                        if numel(Index1)>0 
                            EndTimeAminus1=0;
                        else
                            EndTimeAminus1=operationsSchedule(operation-1,6);
                        end
                        
                        % A+1 start time
                        Index1=find(LastOperationsOfJobs==operation);
                        if numel(Index1)>0
                            StartTimeAplus1=inf;
                        else
                            StartTimeAplus1=operationsSchedule(operation+1,5);
                        end
                        
                        if EndTS-PTOperationsSet(i)<EndTimeAminus1
                            OperationsSet(i)=[];
                            PTOperationsSet(i)=[];
                            PCOperationsSet(i)=[];
                            i=i-1;
                        else
                            StartTAfterMoveA=max(EndTimeAminus1,StartTS);
                            EndTAfterMoveA=StartTAfterMoveA+PTOperationsSet(i);
                            if EndTAfterMoveA>StartTimeAplus1
                                OperationsSet(i)=[];
                                PTOperationsSet(i)=[];
                                PCOperationsSet(i)=[];
                                i=i-1;
                            end
                        end
                        i=i+1;
                    end
                    if numel(OperationsSet)>0
                        %% Positive Effect on Machine J
                        Positive=zeros(1,size(OperationsSet,2));  % Positive is the matrix record the reduced energy on machine j after insertion the operation from other machine
                        SwitchOffEnergy=cell2mat(machinesSet(j,6));
                        UploadPower=cell2mat(machinesSet(j,5));
                        OriginalEnergyForIdelOnJ=min(SwitchOffEnergy,DurS*UploadPower);
                        for i=1:numel(OperationsSet)
                            CurrentEnergyAfterInsertion=(DurS-PTOperationsSet(i))*UploadPower;
                            Positive(i)=OriginalEnergyForIdelOnJ-CurrentEnergyAfterInsertion;
                        end
                        
                        %% Negative Effect on Previous Machine of the operation in OperationsSet
                        Negative=zeros(1,size(OperationsSet,2));
                        PTOperationsOnPreviousMachines=zeros(1,size(OperationsSet,2));
                        PCOperationsOnPreviousMachines=zeros(1,size(OperationsSet,2));
                        for i=1:numel(OperationsSet)
                            operation=OperationsSet(i);  % on the previous machine, operations is performed following the sequence B,A,C and A is the operation going to move
                            PreviousMachineOfI=operationsSchedule(operation,7);
                            OperationsOnPreviousMachine=cell2mat(machinesSchedule(PreviousMachineOfI));
                            
                            SwitchOffPreviousMachine=cell2mat(machinesSet(PreviousMachineOfI,6));
                            UploadPowerPreviousMachine=cell2mat(machinesSet(PreviousMachineOfI,5));
                            
                            OrderOfI=find(OperationsOnPreviousMachine==operation);
                            
                            STA=operationsSchedule(operation,5);
                            ETA=operationsSchedule(operation,6);
                            PTOperationsOnPreviousMachines(i)=ETA-STA;
                            PCOperationsOnPreviousMachines(i)=operationsSchedule(operation,8);
                            
                            if OrderOfI(1)==1       % A is the first operation on the previous machine
                                %% A special case: A is the only opeartion on this machine
                                if numel(OperationsOnPreviousMachine)>1
                                    OperationC=OperationsOnPreviousMachine(OrderOfI(1)+1);
                                    STC=operationsSchedule(OperationC,5);                                    
                                    Negative(i)=0-(min(SwitchOffPreviousMachine,(STC-ETA)*UploadPowerPreviousMachine));  % Negative is energy after move - energy before move
                                else
                                    Negative(i)=0;
                                end
                            else
                                if OrderOfI(1)==numel(OperationsOnPreviousMachine)   % A is the last operation on the previous machine
                                    %% A special case: A is the only operation on this machine
                                    if numel(OperationsOnPreviousMachine)>1
                                        OperationB=OperationsOnPreviousMachine(OrderOfI(1)-1);
                                        ETB=operationsSchedule(OperationB,6);
                                        
                                        Negative(i)=0-(min(SwitchOffPreviousMachine,(STA-ETB)*UploadPowerPreviousMachine));  % Negative is energy after move - energy before move
                                    else
                                        Negative(i)=0;
                                    end
                                else
                                    OperationB=OperationsOnPreviousMachine(OrderOfI(1)-1);
                                    OperationC=OperationsOnPreviousMachine(OrderOfI(1)+1);
                                    
                                    STC=operationsSchedule(OperationC,5);
                                    ETB=operationsSchedule(OperationB,6);
                                    
                                    Negative(i)=min(SwitchOffPreviousMachine,(STC-ETB)*UploadPowerPreviousMachine)-min(SwitchOffPreviousMachine,(STA-ETB)*UploadPowerPreviousMachine)-min(SwitchOffPreviousMachine,(STC-ETA)*UploadPowerPreviousMachine);                                    
                                end
                            end
                        end
                        
                        Effect=zeros(1,size(OperationsSet,2));   % final effect after move
                        for i=1:numel(OperationsSet)                            
                            Effect(i)=Positive(i)-Negative(i)-PTOperationsSet(i)*PCOperationsSet(i) + PTOperationsOnPreviousMachines(i)*PCOperationsOnPreviousMachines(i);                            
                        end
                        
                        %% Choose the operation having the largest effect and move into the idle slot at j
                        if max(Effect)>0
                            Index1=find(Effect==max(Effect));
                            operationMove=OperationsSet(Index1(1)); 
                            CuttingpowerofOperationMove=PCOperationsSet(Index1(1));
                            %% this operation (operationMove) would be moved 
                            Index=1;
                            
                            % find the position of operationMove, and operationMove+1, 
                            OperationMovePosition=find(OperationSequencingList(:,4)==operationMove);
                            OperationMovePosition=OperationMovePosition(1);
                            % OperationMove+1 position
                            Index1=find(LastOperationsOfJobs==operationMove);
                            if numel(Index1)>0
                                OperationMovePlus1Position=OperationNum;
                            else
                                OperationMovePlus1Position=find(OperationSequencingList(:,4)==operationMove+1);
                                OperationMovePlus1Position=OperationMovePlus1Position(1);
                            end
                            
                            % find the position of the operation just after the idel and the operationMove insert into the position min(operationMove+1,OperationAfterIdel)-1
                            PositionMoveIn=min(AfterIdleOperationPosition,OperationMovePlus1Position);
                            
                            Auxiliary=OperationSequencingList(OperationMovePosition,:);
                            OperationSequencingList(OperationMovePosition,:)=0;
                            
                            OperationSequencingList(PositionMoveIn+1:end+1,:)=OperationSequencingList(PositionMoveIn:end,:);
                            OperationSequencingList(PositionMoveIn,:)=Auxiliary;
                            OperationSequencingList(PositionMoveIn,3)=j;
                            
                            OperationSequencingList(OperationSequencingList(:,4)==0,:)=[];
                            
                            %% Update operationsSchedule machinesSchedule
                            
                            solution_VNSNI1.OperationSequencingList=OperationSequencingList;

                            solution_VNSNI1.operationsSchedule(operationMove,7)=j;
                            
                            solution_VNSNI1.operationsSchedule(operationMove,8)=CuttingpowerofOperationMove;
                            
                            solution_VNSNI1 =GetScheduleFromOperationSequencingList(solution_VNSNI1 ,problemSet);
                            
                            solution_VNSNI1 = CreateMachinesSchedule(problemSet,solution_VNSNI1);
                            
                            solution_VNSNI1=RepresentationOfBestSolutionFromGEP(solution_VNSNI1,problemSet);
                            
                            solution_VNSNI1 = CalculateObjectiveFunctions(problemSet,solution_VNSNI1);      
%                             if CheckWhetherFeasibleOfSolution(solution_VNSNI1.OperationSequencingList,problemSet)==0
%                                 disp('***')
%                             end
                        end
                    end
                end
            end
            if Index==1 % success one move and break the loop
                break;
            end
        end
        if Index==1
            %% After this move, check from the first idel slot again
            Solution=solution_VNSNI1;
%             CreateGanttDiagram(solution_VNSNI1,'AfterMove');
            break;
        else
            if j==MachineNum && l==ColumnMax
                TotalChecked=1;  % All idel slots have been checked and no improvement can be realized
            end
        end
    end
end

if Index==0
    solution_VNSNI1=Solution;
end
% CreateGanttDiagram(solution_VNSNI1,'AfterMove');



%% Get Solutions after right and left move
solutionV = GetSolutionAfterRLMove(solution_VNSNI1,problemSet);
end