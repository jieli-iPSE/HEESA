function solution_VNOSR=VNS_OperationInsertionOnMachineRandom(solution,problemSet)
%%
% solution=RepresentationOfBestSolutionFromGEP(solution,problemSet);
solution=solution.solutionRightLiftMove;

%%
OperationNum=problemSet.problemSize.totalOperationsNumber;
JobNum=problemSet.problemSize.jobsNumber;
MachineNum=problemSet.problemSize.machinesNumber;

LastOperationsOfJobs=zeros(JobNum,1);
FirstOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
    FirstOperationsOfJobs(i,1)= problemSet.jobsSet{i,5}(1);
    LastOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(end);
end

%%
OperationSequencingList=solution.OperationSequencingList;

%% Select One machine
OperationsNumOnMachine=zeros(1,MachineNum);
for i=1:MachineNum
    OperationsNumOnMachine(1,i)=numel(solution.operationsSchedule(:,7)==i); %#ok<SZARLOG>
end
MachineSet=find(OperationsNumOnMachine(1,:)>1);
if numel(MachineSet)>0
    SelectedMachine=MachineSet(randperm(numel(MachineSet),1));
    %% Operations On this Machine
    OperationsOnSelectMachine=zeros(1,OperationNum);
    for i=1:OperationNum
        if solution.operationsSchedule(i,7)==SelectedMachine
            OperationsOnSelectMachine(1,i)=1;
        end
    end
    OperationsSet=find(OperationsOnSelectMachine==1);
    if numel(OperationsSet)>1
    %% Select two operatios, the latter one insert forward
    i=1;
    while i<=(numel(OperationsSet)*(numel(OperationsSet)-1)/2)
        OperationInsertion=OperationsSet(randperm(numel(OperationsSet),2));
        if solution.operationsSchedule(OperationInsertion(1),2)==solution.operationsSchedule(OperationInsertion(2),2)  % two selected operations belonging to same job
            i=i+1;
        else
            break;
        end
    end
    if solution.operationsSchedule(OperationInsertion(1),2)~=solution.operationsSchedule(OperationInsertion(2),2)
        LocationsOfOperationInsertion=zeros(1,2);
        LocationsOfOperationInsertion(1)=find(solution.OperationSequencingList(:,4)==OperationInsertion(1));
        LocationsOfOperationInsertion(2)=find(solution.OperationSequencingList(:,4)==OperationInsertion(2));
        if LocationsOfOperationInsertion(1)<LocationsOfOperationInsertion(2)
%             operation1=OperationInsertion(1);
            operation2=OperationInsertion(2);
            LocationOfOperation1BeforeInsertion=LocationsOfOperationInsertion(1);
            LocationOfOperation2BeforeInsertion=LocationsOfOperationInsertion(2);
        else
            operation2=OperationInsertion(1);
%             operation1=OperationInsertion(2);
            LocationOfOperation2BeforeInsertion=LocationsOfOperationInsertion(1);
            LocationOfOperation1BeforeInsertion=LocationsOfOperationInsertion(2);
        end
        %% Insert Operation2 before Operation1
        
        Index=find(FirstOperationsOfJobs==operation2);
        if numel(Index)>0   % operation is the first operation of one job
            LocationOfPreviousOperation2OfSameJob=0;
        else
            LocationOfPreviousOperation2OfSameJob=find(solution.OperationSequencingList(:,4)==operation2-1);
        end
        OperationSequencingList(LocationOfOperation1BeforeInsertion+1:LocationOfOperation2BeforeInsertion,:)=solution.OperationSequencingList(LocationOfOperation1BeforeInsertion:LocationOfOperation2BeforeInsertion-1,:);
        OperationSequencingList(LocationOfOperation1BeforeInsertion,:)=solution.OperationSequencingList(LocationOfOperation2BeforeInsertion,:);

        %% Forward insertion of Operation 2
        Auxiliary=[];
        if LocationOfPreviousOperation2OfSameJob>LocationOfOperation1BeforeInsertion 
            LocationOfPreviousOperation2OfSameJob=find(OperationSequencingList(:,4)==operation2-1);
            for i=LocationOfOperation1BeforeInsertion+1:LocationOfPreviousOperation2OfSameJob
                if OperationSequencingList(i,1)==OperationSequencingList(LocationOfOperation1BeforeInsertion,1)
                    Auxiliary(end+1,:)=OperationSequencingList(i,:); %#ok<AGROW>
                    OperationSequencingList(i,:)=0;
                end
            end
            Add=size(Auxiliary,1);
            OperationSequencingList((LocationOfOperation1BeforeInsertion+Add):(size(OperationSequencingList,1)+Add),:)=OperationSequencingList((LocationOfOperation1BeforeInsertion):(size(OperationSequencingList,1)),:);
            OperationSequencingList((LocationOfOperation1BeforeInsertion):(LocationOfOperation1BeforeInsertion+Add-1),:)=Auxiliary;
        end
 
        OperationSequencingList(OperationSequencingList(:,1)==0,:)=[];
        
        solution_VNOSR.operationsSchedule=solution.operationsSchedule;
        
        %%
        solution_VNOSR.OperationSequencingList=OperationSequencingList;
        
        solution_VNOSR=GetScheduleFromOperationSequencingList (solution_VNOSR,problemSet);
        
        solution_VNOSR = CreateMachinesSchedule(problemSet,solution_VNOSR);
        
        solution_VNOSR=RepresentationOfBestSolutionFromGEP(solution_VNOSR,problemSet);
        
        solution_VNOSR= CalculateObjectiveFunctions(problemSet,solution_VNOSR);

    else % No swap
        solution_VNOSR=solution;
    end
    else
        solution_VNOSR=solution;
    end
else    % No swap
    solution_VNOSR=solution;
end

%%
solution_VNOSR=GetSolutionAfterRLMove(solution_VNOSR,problemSet);
end