function solution_VNEJR=VNS_ExchangeJobRandom(solution,problemSet)
%%
solution=solution.solutionRightLiftMove;
% solution=RepresentationOfBestSolutionFromGEP(solution,problemSet);

%%
solution_VNEJR.operationsSchedule=solution.operationsSchedule;
OperationSequencingList=solution.OperationSequencingList;

%%
JobNum=problemSet.problemSize.jobsNumber;

%% Select Two Jobs
Job1=0;
Job2=0;

while Job1==Job2 
    Job1=randperm(JobNum,1);
    Job2=randperm(JobNum,1);
    
    OperationNumOfJob1=cell2mat(problemSet.jobsSet(Job1,4));
    OperationNumOfJob2=cell2mat(problemSet.jobsSet(Job2,4));
end
%  let OperationNumOfJob1<=OperationNumOfJob2
if OperationNumOfJob1>OperationNumOfJob2
    Job=Job1;
    Job1=Job2;
    Job2=Job;
    OperationNumOfJob1=cell2mat(problemSet.jobsSet(Job1,4));
    OperationNumOfJob2=cell2mat(problemSet.jobsSet(Job2,4));
end
    
SequenceOfJob1=zeros(1,OperationNumOfJob1);
SequenceOfJob2=zeros(1,OperationNumOfJob2);
OperationSequenceOfJob1=zeros(OperationNumOfJob1,4);
OperationSequenceOfJob2=zeros(OperationNumOfJob2,4);

% Job1
for i=1:OperationNumOfJob1
    position=find(OperationSequencingList(:,1)==Job1 & OperationSequencingList(:,2)==i);
    
    OperationSequenceOfJob1(i,:)=OperationSequencingList(position,:);
    SequenceOfJob1(i)=position;    
end

% Job2
for i=1:OperationNumOfJob2
    position=find(OperationSequencingList(:,1)==Job2 & OperationSequencingList(:,2)==i);  
    
    OperationSequenceOfJob2(i,:)=OperationSequencingList(position,:);
    SequenceOfJob2(i)=position;    
end
SequenceOfJob1And2=[SequenceOfJob1,SequenceOfJob2];
SequenceOfJob1And2=sort(SequenceOfJob1And2);

% Exchange position of two jobs

% Job1 
for i=1:OperationNumOfJob1
    NewPositionOfI=SequenceOfJob2(i);
    
    OperationSequencingList(NewPositionOfI,:)=OperationSequenceOfJob1(i,:);
    
    SequenceOfJob1And2(SequenceOfJob1And2(1,:)==NewPositionOfI)=[];
end

% Job2
for i=1:OperationNumOfJob2
    NewPositionOfI=SequenceOfJob1And2(i);
    
    OperationSequencingList(NewPositionOfI,:)=OperationSequenceOfJob2(i,:);
end

%%
solution_VNEJR.OperationSequencingList=OperationSequencingList;

solution_VNEJR= GetScheduleFromOperationSequencingList (solution_VNEJR,problemSet);

solution_VNEJR= CreateMachinesSchedule(problemSet,solution_VNEJR);

solution_VNEJR=RepresentationOfBestSolutionFromGEP(solution_VNEJR,problemSet);

solution_VNEJR= CalculateObjectiveFunctions(problemSet,solution_VNEJR);

%%
solution_VNEJR=GetSolutionAfterRLMove(solution_VNEJR,problemSet);
end