function PercentageOnOffStandbyEnergy=PercentageOnOffStandbyEnergyOfMachines(problemSet,solution)

operationsAssignmentResults=solution.operationsSchedule;
machinesCount=problemSet.problemSize.machinesNumber;
OnOffStanbyEnergyOfMachines=zeros(machinesCount,1);
StanbyEnergyOfMachines=zeros(machinesCount,1);

PercentageOnOffStandbyEnergy=zeros(machinesCount,2);

for i=1:machinesCount
    thismachinetable=operationsAssignmentResults(operationsAssignmentResults(:,7)==i,:);
    [~,o]=sort(thismachinetable(:,5));
    thismachinetable=thismachinetable(o,:);
    assignedoperationscount=numel(solution.machinesSchedule{i,1});
    Pu=problemSet.machinesSet{i,5};
    Eo=problemSet.machinesSet{i,6};
    for j=1:assignedoperationscount-1
        if thismachinetable(j+1,5)>thismachinetable(j,6)
                it=thismachinetable(j+1,5)-thismachinetable(j,6);
                OnOffStanbyEnergyOfMachines(i)=min(Eo,it*Pu)+OnOffStanbyEnergyOfMachines(i);
                StanbyEnergyOfMachines(i)=it*Pu+StanbyEnergyOfMachines(i);
        end
    end
    PercentageOnOffStandbyEnergy(i,1)=i;
    if StanbyEnergyOfMachines(i)>0
        PercentageOnOffStandbyEnergy(i,2)=OnOffStanbyEnergyOfMachines(i)/StanbyEnergyOfMachines(i);
    else
        PercentageOnOffStandbyEnergy(i,2)=0;
    end
end
PercentageOnOffStandbyEnergy=sortrows(PercentageOnOffStandbyEnergy,2,'descend');
end