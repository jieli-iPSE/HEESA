function KnowledgeBaseMachine=KnowledgeBaseOfMachineInitialization(problemSet)

OperationNum=problemSet.problemSize.totalOperationsNumber;
% JobNum=problemSet.problemSize.jobsNumber;
MachineNum=problemSet.problemSize.machinesNumber;
%% OperationsWithMultiple Machines
    OperationsMultipleMachine=zeros(1,OperationNum);
    for i=1:OperationNum
        if cell2mat(problemSet.operationsSet(i,4))>1
            OperationsMultipleMachine(1,i)=1;
        end
    end
    OperationsSet=find(OperationsMultipleMachine==1); 
%% Matix of assignment Knowledge  first column: operation index, column number in this matrix: 1+machineNum

KnowledgeBaseMachine=zeros(numel(OperationsSet),MachineNum+1);
for i=1:numel(OperationsSet)
    operation=OperationsSet(i);
    KnowledgeBaseMachine(i,1)=operation;
    MachinesForOperation=cell2mat(problemSet.operationsSet(operation,5));
    for j=1:numel(MachinesForOperation)
        machine=MachinesForOperation(j);
        KnowledgeBaseMachine(i,machine+1)=1/numel(MachinesForOperation);
    end
end
end