function mutationRate=Adaptivemutation(mutationRateInitial,TEC,gen)

Ave=TEC.AverageResult;
Max=TEC.MaxResult;
Min=TEC.MinResult;
% Ave
% Max
% Min
% mutationRate=mutationRateInitial*(2+0.5*Ave^3/((max(0.0001,(Max-Min)^3))+Ave^3));


mutationRate=mutationRateInitial*1.2^(((gen-1)*Ave/((Max-Min)+Ave))^0.3);
end