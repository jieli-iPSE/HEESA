function CompleteTimeOfMachines=MakespanOnMachine(solution,problemSet)

MachineNum=problemSet.problemSize.machinesNumber;

CompleteTimeOfMachines=zeros(MachineNum,2);

for j=1:MachineNum
    CompleteTimeOfMachines(j,1)=j;
    AssignedOperationsOnMachine=cell2mat(solution.machinesSchedule(j,1));
    for i=1:numel(AssignedOperationsOnMachine)
        operation=AssignedOperationsOnMachine(1,i);
        processingTime=solution.operationsSchedule(operation,6)-solution.operationsSchedule(operation,5);
        CompleteTimeOfMachines(j,2)= CompleteTimeOfMachines(j,2)+processingTime;
    end
end
CompleteTimeOfMachines=sortrows(CompleteTimeOfMachines,2,'descend');

end