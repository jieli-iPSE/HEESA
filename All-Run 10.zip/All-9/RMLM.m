function solution = RMLM (solution,problemSet)
gap=-inf;
gap_RM=-inf;
gap_LM=-inf;

while gap~=0
    ResultLastIteration=solution.obj;
    SolutionRightMove=solution;

    while gap_RM<0
        PreviousResult=SolutionRightMove;
        SolutionRightMove =Rightmove(SolutionRightMove,problemSet);
        
        gap_RM=SolutionRightMove.obj-PreviousResult.obj;
        
        if PreviousResult.obj<SolutionRightMove.obj
            SolutionRightMove= PreviousResult;
        end
    end
    solution=SolutionRightMove;
    while gap_LM<0
        PreviousResult=solution;
        solution =LeftMove(solution,problemSet);
        gap_LM=solution.obj-PreviousResult.obj;
        if PreviousResult.obj<solution.obj
            solution= PreviousResult;
        end
    end
    gap=solution.obj-ResultLastIteration;

end
end