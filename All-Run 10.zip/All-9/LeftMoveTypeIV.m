function operationsSchedule=LeftMoveTypeIV(LastOperationsOfJobs,operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOnMachines,StartingTimeOfThisBlock,MachineTime,Machine)
Movingstep1=zeros(numel(operations),1);
Movingstep2=zeros(numel(operations),1);
for i=1:numel(operations)
    operation=operations(i);
    Movingstep1(i,1)=operationsSchedule(operation,5)-operationsScheduleAfterLeftMove(operation,4);
    
    ind=find(LastOperationsOfJobs==operation);
    if numel(ind)==0
        % if the operation is not the last operation of its job
        LaterOperationOfSameJob=operation+1;
        WhetherFirstOperationOnMachine=find(FirstOperationsOnMachines==LaterOperationOfSameJob);
        if numel(WhetherFirstOperationOnMachine)==0
            StartingtimeOfLaterOperation=operationsSchedule(LaterOperationOfSameJob,5);
            MachineOfLaterOperation=operationsSchedule( LaterOperationOfSameJob,7);
            
            Index=find(operationsSchedule(:,7)==MachineOfLaterOperation & operationsSchedule(:,6)<=StartingtimeOfLaterOperation);
            EndtimeOfThieOperation=operationsSchedule(operation,6);
            if max(operationsSchedule(Index,6))<EndtimeOfThieOperation && EndtimeOfThieOperation-Movingstep1(i,1)<=max(operationsSchedule(Index,6))
                LengthOfIdelAfterFormerOperationOfSameJob=EndtimeOfThieOperation-max(operationsSchedule(Index,6));
                Movingstep2(i,1)=LengthOfIdelAfterFormerOperationOfSameJob;
            end
        end
    end
end
durationLength=StartingTimeOfThisBlock-MachineTime(Machine,1);
Length=min(min(Movingstep1),min(max(Movingstep2),durationLength));
if Length>0
    % Moving
    for i=1:numel(operations)
        operation=operations(i);
        operationsSchedule(operation,6)=operationsSchedule(operation,6)-Length;
        operationsSchedule(operation,5)=operationsSchedule(operation,5)-Length;
    end
end

end