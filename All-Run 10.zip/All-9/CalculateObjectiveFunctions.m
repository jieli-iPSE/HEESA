function [solution] = CalculateObjectiveFunctions(problemSet,solution)

    solution.Cmax=[];
    solution.fl=0;
    solution.Wt=[];
    solution.PtPc=[];
    solution.Wmax=[];
    solution.obj=[];
    solution.Cmax=max(solution.operationsSchedule(:,6));
    solution.machinesW=zeros(problemSet.problemSize.machinesNumber,1);
    solution.machinesPcPt=zeros(problemSet.problemSize.machinesNumber,1);
    for i=1:problemSet.problemSize.machinesNumber
        assignedOperations=cell2mat(solution.machinesSchedule(i,1))';
        assignedOperationNumber=numel(assignedOperations);
        for j=1:assignedOperationNumber
            operation=assignedOperations(j,1);
            processingTime=solution.operationsSchedule(operation,6)-solution.operationsSchedule(operation,5);
            solution.machinesW(i,1)=processingTime+solution.machinesW(i,1);
            pc=solution.operationsSchedule(operation,8);
            solution.machinesPcPt(i,1)=processingTime*pc+solution.machinesPcPt(i,1);
        end
    end
    for i=1:problemSet.problemSize.jobsNumber
        operations=problemSet.jobsSet{i,5};
        lastOperation=operations(1,end);
        solution.fl=solution.fl+solution.operationsSchedule(lastOperation,6);
    end
    [OnOffStanbyEnergyOfMachines]=CalculateOnOffStanbyEnergy(problemSet,solution);
    solution.OnOffStEng=sum(OnOffStanbyEnergyOfMachines);
    %solution.fl=solution.fl/(problemSet.problemSize.jobsNumber);
    solution.Wt=sum(solution.machinesW(:,1));
    solution.PtPc=sum(solution.machinesPcPt(:,1));
    solution.Wmax=max(solution.machinesW(:,1));
    %solution.obj=solution.Cmax;
    solution.obj=(solution.Cmax*problemSet.indirectFraction+solution.PtPc+solution.OnOffStEng);
    %solution.obj=(solution.Cmax+solution.fl)/2;
    [~,order]=sort(solution.operationsSchedule(:,5));
    solution.order(1,:)=order';
    solution.order(2,:)=solution.operationsSchedule(order,7);
end

