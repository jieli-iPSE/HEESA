function selectedOperatin=SelectOperation_GEPPRMultiGene(machine,waitingList,problemSet,schedulingMatrics,Chromosome,LastRow,LeftRight,GeneNumber)
%1:it idle time, 2: pt  processing time, 3: pc cutting power, 4: pu unload power 5: nr unschuduled opearion 

waitingOperationsNumber=numel(waitingList);
priorityMatrix=zeros(waitingOperationsNumber,1);
machinesStartTimes=schedulingMatrics.machinesStartTimes;

for i=1:waitingOperationsNumber
    operation=waitingList(i);
    assignableMachines=cell2mat(problemSet.operationsSet(operation,5))';
    index=find(assignableMachines==machine);
    processingTimes=cell2mat(problemSet.operationsSet(operation,6))';
    pt=processingTimes(index(1,1),1);

    pcs=cell2mat(problemSet.operationsSet(operation,8))';
    pc=pcs(index(1,1),1);

    relatedJob=cell2mat(problemSet.operationsSet(operation,2));
    relatedJobOperationNumber=cell2mat(problemSet.jobsSet(relatedJob,4));
    orderInJob=cell2mat(problemSet.operationsSet(operation,3));
    nr=relatedJobOperationNumber-orderInJob;

    startTimeofMachine=machinesStartTimes(machine,2);
    
    RowofoperationinNextEventsList=find(schedulingMatrics.nextEventsList(:,3)==operation);
    if numel(RowofoperationinNextEventsList)>1
        j=1;
        while j<=numel(RowofoperationinNextEventsList)
            if schedulingMatrics.nextEventsList(RowofoperationinNextEventsList(j),2)==3
                RowofoperationinNextEventsList(j)=[];
                j=j-1;
            end
            j=j+1;
        end
    end
    releaseTimeofOperation=schedulingMatrics.nextEventsList(RowofoperationinNextEventsList,1);
    it=releaseTimeofOperation-startTimeofMachine;
    if machinesStartTimes(machine,2)==0
        it=0;
    end
    it=max(0,it);
    pu=problemSet.machinesSet{machine,5};
    
    priority=calculatePriorityMultiGene(it,nr,pt,pc,pu,Chromosome,LastRow,LeftRight,GeneNumber);

    priorityMatrix(i,1)=priority;

    [~, index] = min(priorityMatrix);
    selectedOperatin=waitingList(index);
end
   
end

