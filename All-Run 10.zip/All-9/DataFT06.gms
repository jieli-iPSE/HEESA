set l /1*100/
    m /1*100/;

alias (m,mm), (l,ll);

parameter SS(l,m);

*Reading from excel
$onecho > taskin.txt
par=SS rng=Data!A1:AF21
$offecho

$call gdxxrw.exe DataFT06.xlsx @taskin.txt
$gdxin DataFT06.gdx
$load SS
$gdxin

parameter noot number of taks
          nojt number of task in noot task
          it curent task (data are transfered for this task
          jt curent tasks whithin the operation
          alpha fixed processing time of task i on j
          ptc 1 if processing time is examined
          noji number of unit in task i
          pc cutting power
          ij
          dne(l,m)
          dnem(l,m)
;

dnem(l,m) = 0;
it = 1;


loop((l,m),
         if(ord(m) = 1,
                 noot = SS(l,m);
         );
         if(ord(m) = 2,
                 nojt = SS(l,m)
         );
         if(ord(m) = 3,
                 ptc = 1;
                 noji = SS(l,m)+1;
                 ij = 1;
                 dne(l,m) = 0;
         );
         loop((i,j)$(ord(j) =noji and ord(i) = it and ord(m) > 3 and dne(l,m) = 0 and dnem(l,m) = 0),
                 if(ptc = 1 and ij = 1,
                         alpha(i,j) = SS(l,m);
                         ptc = 0;
                 elseif ptc = 0 and ij = 1,
                         pc(i,j) = SS(l,m)/1000;
                         ij = 0;
                         nojt = nojt - 1;
                         ptc = 1;
                 );
                 if(ij = 0 and nojt >0,
                         noji = SS(l,m+1) + 1;
                         ij = 1;
                         dne(l,m) = 1;
                         dne(l,m+1) = 1;
                 elseif ij = 0 and nojt = 0,
                         nojt = SS(l,m+1);
                         noji = SS(l,m+2)+1;
                         ij = 1;
                         it = it + 1;
                         dne(l,m) = 1;
                         dne(l,m+1) = 1;
                         dne(l,m+2) = 1;
                         noot = noot - 1;
                 );
                 if(noot = 0,
                         loop((ll,mm)$(ord(ll) = ord(l) and ord(mm)>ord(m)),
                         dnem(ll,mm) = 1;
                         );
                 );
         );
);

display alpha, pc;

sets   ut / 1*30 /;

parameter Tstart(ut) half time required to switch on-off
         /  1    20
            2     7
            3    14
            4    12
            5    19
            6    16
            7    11
            8     4
            9    17
           10    11
           11    14
           12    17
           13    19
           14    16
           15     6
           16    10
           17    19
           18    19
           19    10
           20    19
           21     4
           22     9
           23    17
           24     4
           25     6
           26     7
           27     7
           28    14
           29     8
           30     7      /;
