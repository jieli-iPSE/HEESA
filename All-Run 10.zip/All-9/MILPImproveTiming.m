function solutionMILP=MILPImproveTiming(solution,problemSet,IndexofProblem)
OperationNum=max(cell2mat(problemSet.operationsSet(:,1)));

MachineNum=max(cell2mat(problemSet.machinesSet(:,1)));

EventPointofMachine=zeros(MachineNum,1);

for j=1:MachineNum
    OperationsOnj=solution.machinesSchedule{j};
    EventPointofMachine(j)=numel(OperationsOnj);
end
EventPoint=max(EventPointofMachine);

Allocation=zeros(OperationNum,MachineNum,EventPoint);

for j=1:MachineNum
    OperationsOnj=solution.machinesSchedule{j};
    IndexN=1;
    for i=1:numel(OperationsOnj)
       operation= OperationsOnj(i);
       Allocation(operation,j,IndexN)=1;
       IndexN=IndexN+1;
    end
end
% data transfer------------------------------------------------------------------------------------------------------------------------------------------------
fixN.name='n';
fixN.val=linspace(1,EventPoint,EventPoint)';
fixN.type='set';

fix1.name='WGEP';
fix1.type='parameter';
fix1.val=Allocation;
fix1.form='full';
fix1.dim=3;

% Sequence=zeros(OperationNum,OperationNum,MachineNum);
% for j=1:MachineNum
%     OperationsOnj=solution.machinesSchedule{j};
%     if numel(OperationsOnj)>1
%        for i1=1:(numel(OperationsOnj)-1)
%           for i2=i1+1:numel(OperationsOnj)
%               Sequence(OperationsOnj(i1),OperationsOnj(i2),j)=1;
%           end
%        end
%     end 
% end
% fix2.name='Sequence';
% fix2.type='parameter';
% fix2.val=Sequence;
% fix2.form='full';
% fix2.dim=3;

addpath('C:\GAMS\win64\24.6')

wgdx('MtoG_New.gdx',fixN,fix1);

gams(IndexofProblem);


TECMILP.name='TEC';
CPUMILP.name='CPU';
MSMILP.name='MS';
PtPc.name='SEL';
Switch.name='SEO';
Standby.name='SES';
OperationST.name='StartTIME';
OperationFT.name='FinishTIME';

[TECMILP]=rgdx('GtoM_Z_X_XS',TECMILP);
[CPUMILP]=rgdx('GtoM_Z_X_XS',CPUMILP);
[PtPc]=rgdx('GtoM_Z_X_XS',PtPc);
[MSMILP]=rgdx('GtoM_Z_X_XS',MSMILP);
[Standby]=rgdx('GtoM_Z_X_XS',Standby);
[Switch]=rgdx('GtoM_Z_X_XS',Switch);

solutionMILP.obj=TECMILP.val;
solutionMILP.CPU=CPUMILP.val;
solutionMILP.Cmax=MSMILP.val;
solutionMILP.PtPc=PtPc.val;
solutionMILP.StandbyMILP=Standby.val;
solutionMILP.SwitchMILP=Switch.val;
solutionMILP.OnOffStEng=Switch.val+Standby.val;
[OperationST]=rgdx('GtoM_Z_X_XS',OperationST);

[OperationFT]=rgdx('GtoM_Z_X_XS',OperationFT);


OperationsST=OperationST.val;
OperationsFT=OperationFT.val;

for i=1:OperationNum
    if numel(find(OperationsST(:,1)==i))==0
       OperationsST(end+1,1)=i;
       OperationsST(end,2)=0;
    end 
end
OperationsST=sortrows(OperationsST,1);
OperationSchedule=solution.operationsSchedule;
OperationSchedule(:,5)=OperationsST(:,2);
OperationSchedule(:,6)=OperationsFT(:,2);

solutionMILP.operationsSchedule=OperationSchedule;
[solutionMILP] = TransformOperationsScheduleToMachinesSchedule(problemSet,solutionMILP);
% disp(solutionMILP.CPU);
end



