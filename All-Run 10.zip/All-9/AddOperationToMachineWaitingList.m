function [schedulingMatrics] = AddOperationToMachineWaitingList(operation,machine,schedulingMatrics,processingTime)
    schedulingMatrics.machinesWaitingList(machine,operation)=1;
    schedulingMatrics.machinesWaitingListLoad=schedulingMatrics.machinesWaitingListLoad+processingTime;
end

