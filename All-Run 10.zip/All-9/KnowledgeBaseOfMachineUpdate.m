function KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,solution)
%% Parameters of learning
a=0.5;
%% Update 
OperationNumWithMultipleMachine=size(KnowledgeBaseMachine,1);
MachineNum=size(KnowledgeBaseMachine,2)-1;

for i=1:OperationNumWithMultipleMachine
    operation=KnowledgeBaseMachine(i,1);
    CurrentMutation=solution.operationsSchedule(operation,7);
    KnowledgeBaseMachine(i,CurrentMutation+1)=KnowledgeBaseMachine(i,CurrentMutation+1)+a*1;
end

%% Normalization
for i=1:OperationNumWithMultipleMachine
    Summation=sum(KnowledgeBaseMachine(i,2:end));
    for j=2:MachineNum+1
        KnowledgeBaseMachine(i,j)=KnowledgeBaseMachine(i,j)/Summation;
    end
end
end