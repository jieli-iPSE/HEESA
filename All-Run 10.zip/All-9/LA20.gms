
$set matout "'GtoM_Z_X_XS.gdx',TEC,MS,CPU,SEL,SEO,SES,SIE,StartTime,FinishTIME";

$TITLE Four index model (4-M2)
$offsymxref
$offsymlist
$offdigit
$offupper
$setglobal NN 14
$setglobal DN 0
$onempty
$ontext
* Example LA20 (10x10)
$offtext
$offlisting

Sets  s      States        / S1*S110 /
      j      Units         / 1*10  /
      i      Tasks         / 1*100 /

      r(s)   Raw Materials /   /
      In(s)  Intermidiate  /  /
      pr(s)  Product       /  /
      Re(i)  Recycling     /  /;

Scalar   O          Number of operations        / 10 /;

loop(i,
r(s)$(ord(s) = 1 or (ord(i)/O)+1 + ord(i) = ord(s)) = 1;
pr(s)$((ord(i)/O) + ord(i) = ord(s)) = 1;
);
In(s)$(not r(s) and not pr(s)) = 1;
display r, in, pr;

Alias   (ii,i)
        (jj,j)
;
*---------------------
Scalar dell / %DN% / ;

Scalar    H          Horizon time     / 10000 /
          beta       Coefficient of indirect energy consumption / 1 /;

parameter PU(j)  unload power
         /  1 0.72
            2 2.43
            3 2.85
            4 1.22
            5 1.02
            6 1.22
            7 0.78
            8 0.26
            9 1.47
            10 1.55   /;

$include "DataLA20.gms"

parameter EO(j)  switch on-off energy;
loop((ut,j),
   if(ord(ut)=ord(j),
      EO(j) = 2*Tstart(ut)*PU(j);
   );
);

parameter  RHO(s,i)   The portion of tasks i consuming(-ve) and producing(+ve) state s;
         rho(s,i)$(ceil(ord(i)/O)-1 + ord(i) = ord(s)) = -1;
         rho(s,i)$(ceil(ord(i)/O) + ord(i) = ord(s)) = 1;

parameter  SUIT(i,j)    Suitability matrix for task i in unit j;
         suit(i,j)$(alpha(i,j)) = 1;


*--------Data transfer----------------------------------------------------------
Sets     n    eventpoints
;

Alias    (n,nn)
;

Parameter        wGEP(i,j,n);

$gdxin   MtoG_New
$load    n,wGEP
$gdxin

*parameter Mj(j)  big-M for each unit;
*         Mj(j) = H;

*parameter Nmin(j) minimum number of operations that can be processed in unit j;
*         Nmin(j) = SUM((i)$(SUIT(i,j) and SUM(jj$(ord(jj)<>ord(j) and SUIT(i,jj)),1)=0),1);

*parameter Nmax(j) maximum number of operations that can be processed in unit j;
*         Nmax(j) = SUM((i)$(SUIT(i,j)),1);

*display Nmin, Nmax;

*----Data from GEP of Assignment and Sequecne----------------------------------------------------



*-------------------------------------------------------------------------------------------------

Binary variables
*        w(i,j,n,nn)      Assign the end of task i to event point nn that starts at n
        x(j,n)           1 if unit j standby;

Positive variables
        EU(j,n)          Unload energy (switch on-off not calculated)
        ES(j,n)          Standby energy consumption
        TLEC             Total load energy
        ts(j,n)          Time that unit j starts at point n
        tf(j,n)          Time that unit j finishes at event point n
*        t(s,n)           Time that state s is available to be consumed at event point n
         T(s)            available time of state s
        MS               Makespan;

variable
        z               TEC;

*-------------------------------------------------------------------------------

Equations
        obj                     Objective function definition
        ES1(j,n)                Force standby energy consumption to be zero if switch off
        ES2(j,n)
        ES3(j,n)
*        allco(j,n)              Allocation constraint
*        allco2(i)               Each task has to be performed only once
*        alloc3(s,i,ii,jj,n)     Consuming tasks must be after producing tasks (Or jobs should be performed in sequence in an operation)
*        eq6a(j)
*        eq6b(j)
        MScalc(j,n)             Makespan calculation
        cdur(j,n)               Define the duration of a process that take place in unit j from event n to nn
        cseq_ss(j,n)            Sequence constraint for same tasks at the same unit j
*        timematch1(s,j,n)       Time matching constraint between T(s n) and finish time of tasks producing state s
*        timematch2(s,j,n)       Time matching constraint between T(s n) and start time of tasks consuming state s for non-recycling tasks
*        timematch2r(s,j,n)      Time matching constraint between T(s n) and start time of tasks consuming state s for recycling tasks
*        seqconts(s,n)           Sequence constraints for T(s n)

SeqOnDifferentUnits1(s,i,j,n)
SeqOnDifferentUnits2(s,ii,jj,nn)
*        tight(s,n)
        ;
*-------------------------------------------------------------------------------
obj..
        z =e= SUM((j,n)$(ord(n)>1),ES(j,n) + EO(j)*(1-x(j,n)))
              + SUM((i,j,n)$SUIT(i,j),wGEP(i,j,n)*alpha(i,j)*pc(i,j))
              + beta*MS;

*-----------------Standby energy calculation------------------------------------
ES1(j,n)..
         ES(j,n) =L= EO(j)*x(j,n);
ES2(j,n)$(ord(n)>1)..
         ES(j,n) =L= (Ts(j,n) - Tf(j,n-1))*PU(j);
ES3(j,n)$(ord(n)>1)..
         ES(j,n) =G= (Ts(j,n) - Tf(j,n-1))*PU(j) - H*PU(j)*(1-x(j,n));
MScalc(j,n)$(ord(n)=card(n))..
         Tf(j,n) =L= MS;
*-------------------------------------------------------ALLOCATION CONSTRAINTS
*allco(j,n)..
*         SUM((i,nn,n2)$(SUIT(i,j) and ord(nn)>=ord(n)-dell and ord(nn)<=ord(n) and ord(n2)>=ord(n) and ord(n2)<=ord(nn)+dell),W(i,j,nn,n2)) =L= 1;
*allco2(i)..
*         SUM((j,n,nn)$(SUIT(i,j) and ord(nn)>=ord(n) and ord(nn)<=ord(n)+dell),w(i,j,n,nn)) =E= 1;
*alloc3(s,i,ii,jj,n)$(SUIT(ii,jj) and rho(s,ii)<0 and In(s) and rho(s,i)>0)..
*         SUM((j,n2,nn)$(SUIT(i,j) and ord(n2)<=ord(n) and ord(nn)>=ord(n2) - dell and ord(nn)<=ord(n2)),w(i,j,nn,n2)) =G= SUM(nn$(ord(nn)>=ord(n) and ord(nn)<=ord(n) + dell),w(ii,jj,n,nn));
*eq6a(j)$(Nmin(j))..
*         SUM((i,n,nn)$(SUIT(i,j) and ord(nn)>=ord(n) and ord(nn)<=ord(n) + dell),w(i,j,n,nn)) =G= Nmin(j);
*eq6b(j)..
*         SUM((i,n,nn)$(SUIT(i,j) and ord(nn)>=ord(n) and ord(nn)<=ord(n) + dell),w(i,j,n,nn)) =L= Nmax(j);
*-------------------------------------------------------------------------------
*cdur(j,n)..
* Tf(j,n) =e= Ts(j,n) +  SUM((i,n2)$(SUIT(i,j) and ord(n2)<=ord(n)+dell and ord(n2)>=ord(n)), w(i,j,n,n2) * ALPHA(i,j)) ;
cdur(j,n)..
Tf(j,n) =e= Ts(j,n) +  SUM(i$SUIT(i,j), wGEP(i,j,n) * ALPHA(i,j));
*------------------------------------------SEQUENCING CONSTRAINTS
*-------------------------------------------------------------------------------
cseq_ss(j,n)$(ord(n)<card(n))..
Ts(j,n+1) =g= Tf(j,n);
*-------------------------------------------------------------------------------
*--------------------------TIME MATCHING CONSTRAINTS----------------------------
*timematch1(s,j,n)$(In(s) and SUM(i$(SUIT(i,j) and RHO(s,i)>0), RHO(s,i))>0)..
*         T(s,n) =G= Tf(j,n) - Mj(j)*(1 - SUM((i,nn)$(SUIT(i,j) and RHO(s,i)>0 and ord(nn)<=ord(n) and ord(nn)>=ord(n)-dell),w(i,j,nn,n)));
*timematch2(s,j,n)$(In(s) and SUM(i$(SUIT(i,j) and RHO(s,i)<0), RHO(s,i))<0 and SUM((ii,jj)$(SUIT(ii,jj) and RHO(s,ii)>0 and not Re(ii)), RHO(s,ii))>0)..
*         T(s,n) =L= Ts(j,n) + Mj(j)*(1-SUM((i,nn)$(SUIT(i,j) and RHO(s,i)<0 and ord(nn)<=ord(n)+dell and ord(nn)>=ord(n)),w(i,j,n,nn)));
*timematch2r(s,j,n)$(In(s) and ord(n)<card(n) and SUM(i$(SUIT(i,j) and RHO(s,i)<0),RHO(s,i))<0 and SUM((ii,jj)$(SUIT(ii,jj) and RHO(s,ii)>0 and Re(ii)),RHO(s,ii))>0)..
*         T(s,n) =L= Ts(j,n+1) + Mj(j)*(1-SUM((i,nn)$(SUIT(i,j) and RHO(s,i)<0 and ord(nn)<=ord(n)+1+dell and ord(nn)>=ord(n)+1),w(i,j,n+1,nn)));

*seqconts(s,n)$(ord(n)<card(n) and In(s))..
*         T(s,n) =L= T(s,n+1);
SeqOnDifferentUnits1(s,i,j,n)$(In(s) and RHO(s,i)>0 and wGEP(i,j,n)=1)..
         T(s)=G= Tf(j,n);

SeqOnDifferentUnits2(s,ii,jj,nn)$(In(s) and RHO(s,ii)<0 and wGEP(ii,jj,nn)=1)..
         T(s)=L= Ts(jj,nn);
*-------------------------------------------------------------------------------
*------Tightening constraints
*tight(s,n)$(In(s) and ord(n) = card(n))..
*         T(s,n) =L= MS;
*-------------------------------

* Bounds on variables
  Ts.up(j,n) = H;
  Tf.up(j,n) = H;
*  T.up(s,n) = H;
   T.up(s) = H;

* Fix some variables
*  w.fx(i,j,n,nn)$(ord(nn)<ord(n)) = 0;
*  w.fx(i,j,n,nn)$(not SUIT(i,j)) = 0;

  EU.fx(j,n)$(ord(n) = 1) = 0;
  x.fx(j,n)$(ord(n)=1) = 0;


x.fx(j,n)$(sum((nn,i)$(ord(nn)>=ord(n) and suit(i,j)),wGEP(i,j,nn))=0)=1;





*=======================================================================================
MODEL sch  / ALL /;

*sch.holdfixed = 0;

option mip = CPLEX;
option optcr = 0.0;
option reslim = 200;
option iterlim = 1e08;
option limrow = 0;
option limcol = 0;
option solprint = off;
option threads=0;

solve sch using MIP minimizing z;

*-------------------------
Display x.l
        ts.l, tf.l
        T.l
        z.l
        MS.l;
*-------------------------

*------Energy analysis----------------------------------------------------------
parameter SEL    Total subproblem cuting energy consumption
          SEO    Total switch on-off energy consumption
          SES    Total standby energy consumption
          SIE    Total indirect energy consumption
          TEC    Total energy consumption;



SEL = SUM((i,j,n)$SUIT(i,j),wGEP(i,j,n)*alpha(i,j)*pc(i,j));
SEO = SUM((j,n)$(ord(n)>1),EO(j)*(1-x.l(j,n)));
SES = SUM((j,n)$(ord(n)>1),ES.l(j,n));
SIE = beta*MS.l;
TEC = SEL + SEO + SES + SIE;
display SEL, SEO, SES, SIE, TEC;

parameter CPU;
CPU= sch.RESUSD;

Parameter StartTime(i),FinishTIME(i);


StartTime(i)=sum((j,n)$(suit(i,j) and wGEP(i,j,n)=1),Ts.l(j,n));
FinishTime(i)=sum((j,n)$(suit(i,j) and wGEP(i,j,n)=1),Tf.l(j,n));


display Ts.l,Tf.l, wGEP,StartTime,FinishTime;

$if exist GtoM_Z_X_XS.gms $include GtoM_Z_X_XS.gms
execute_unload %matout%;

