function [child] = GEPMutationMultiGene(parent,headSize,functionsNumber,elementsSize,GeneNumber,GeneSize)
child.chromosome=cell(2,1);
ElementNum=elementsSize;

for j=1:2
    Chromosome=parent.chromosome{j};
    ChromosomeChild=cell(GeneNumber+1,1);
    for i=1:(GeneNumber+1)
        Gene=Chromosome{i};
        if i==GeneNumber+1
            elementsSize=GeneNumber;
        end
        %% mutation of head part
        position=randi([1,headSize],1,1);
        if position==1
            rnd=randi([1,functionsNumber],1,1);
            Gene(1,position)=rnd;
            Gene(2,position)=1;
            
        elseif 1<position && position<=headSize
            rnd1=round(randi([0,1],1,1));
            if rnd1==1
                rnd=randi([1,functionsNumber],1,1);
                %chromosome(1,i)=char(functionsSet(1,rnd));
                Gene(1,position)=rnd;
                Gene(2,position)=1;
            else
                rnd=randi([1,elementsSize],1,1);
                %chromosome(1,i)=char(elementsSet(1,rnd));
                Gene(1,position)=rnd;
                Gene(2,position)=2;
            end
        end
        %% mutation of tail part
        position=randi([headSize+1,GeneSize],1,1);
        rnd=randi([1,elementsSize],1,1);
        Gene(1,position)=rnd;
        ChromosomeChild{i}=Gene;
        
        elementsSize=ElementNum;
    end
    child.chromosome{j}=ChromosomeChild;
end
end

