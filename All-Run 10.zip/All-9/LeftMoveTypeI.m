function operationsSchedule=LeftMoveTypeI(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine,StartingTimeOfThisBlock)
Movingstep=zeros(numel(operations),1);
for i=1:numel(operations)
    operation=operations(i);
    Movingstep(i,1)=operationsSchedule(operation,5)-operationsScheduleAfterLeftMove(operation,4);
    
    ind=find(FirstOperationsOfJobs==operation);
    if numel(ind)==0
        % if the operation in not the last operation of its job, and its next operation of the same job belongs to the same block as it
        ind2=find(operations==operation-1);
        if numel(ind2)==1
            Movingstep(i,1)=inf;
        end
    end
end
durationLength=StartingTimeOfThisBlock-MachineTime(Machine,1);
Length=min(min(Movingstep),durationLength);
if Length>0
    % Moving
    for i=1:numel(operations)
        operation=operations(i);
        operationsSchedule(operation,6)=operationsSchedule(operation,6)-Length;
        operationsSchedule(operation,5)=operationsSchedule(operation,5)-Length;
    end
end

end