function [index] = GEPTournamentSelection(index1,index2,pop)


    solution1=pop{index1};
    solution2=pop{index2};
    if solution1.obj < solution2.obj
        index=index1;
    else
        index=index2;
    end


end

