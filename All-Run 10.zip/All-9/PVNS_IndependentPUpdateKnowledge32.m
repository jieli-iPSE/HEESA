function [solution]=PVNS_IndependentPUpdateKnowledge32(solution,problemSet,MAXGENVNS,processorNum,GEPCPU)
%% CPU Upper based on the problem size
CPUUpperBound=CalculateCPULimitation(problemSet);

CPUUpperBound=200;
%% there are multiple solutions saved in solution, each solution is accepted by one processor, number of solutions = processorNum/3;
%% For different solutions from GEP, conduct the VNS independently 

SolutionNumFromGEP=size(solution,1);
GenMaxForEachSolution=ceil(MAXGENVNS/processorNum);

%% Intialization of machine knowledge
KnowledgeBaseMachine=KnowledgeBaseOfMachineInitialization(problemSet);

%% Update knowledge base of machine based on solutions from GEP
for i=1:SolutionNumFromGEP
    KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,solution{i}.solutionRightLiftMove);
end

%% Intialization of VNS solutions in gen=1
gen=ones(SolutionNumFromGEP,1);
current_solution=cell(SolutionNumFromGEP,1);
current_result=zeros(SolutionNumFromGEP,1);

parfor i=1:SolutionNumFromGEP
    current_solution{i}=solution{i}; 
    current_result(i)=current_solution{i}.solutionRightLiftMove.obj; 
end
% current_result
Solution=cell(SolutionNumFromGEP,1);
Get_result=zeros(SolutionNumFromGEP,1);
%% out loop of VNS
% while min(gen)<=GenMaxForEachSolution && max(gen)<=GenMaxForEachSolution*5
% while min(gen)<=GenMaxForEachSolution
while toc+GEPCPU<=CPUUpperBound

%     gen
%     current_result
    %% Search process using VNS
    parfor i=1:SolutionNumFromGEP
%         if gen(i)<=GenMaxForEachSolution
            Solution{i}=SH_VND32(current_solution{i},problemSet,KnowledgeBaseMachine);   % %%%%% KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,current_solution);
            Get_result(i)=Solution{i}.solutionRightLiftMove.obj;
%         end
    end
    %% Update knowledge base of machine assignment
    for i=1:SolutionNumFromGEP
        KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,Solution{i}.solutionRightLiftMove);
    end
    %% determine the generation number for each solution 
    parfor i=1:SolutionNumFromGEP
%         if gen(i)<=GenMaxForEachSolution
            if Get_result(i)<current_result(i)
                current_solution{i}=Solution{i};
                current_result(i)=Get_result(i);
                gen(i)=1;  
            else
                gen(i)=gen(i)+1;
            end
%         end
    end 
    if min(current_result)<184
        break;
    end
end

minTEC=min(current_result);
Index=find(current_result==minTEC);

solution=current_solution{Index(1)};

% %% Machine knowledge base is not updated
% parfor i=1:SolutionNumFromGEP
%     gen=1;
%     current_solution=solution{i};
%     current_result=current_solution.solutionRightLiftMove.obj;
%     
%     while gen<=GenMaxForEachSolution
% %         gen
% %         current_result
%         [Solution]=SH_VND3(current_solution,problemSet,KnowledgeBaseMachine);   %%%%% KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,current_solution);
%         Get_result=Solution.solutionRightLiftMove.obj;
%         if Get_result<current_result
%             current_solution=Solution;
%             current_result=Get_result;
%             gen=1;
%         else
%             gen=gen+1;
%         end
%     end
%     SolutionsVNS{i}=current_solution;
%     ResultsVNS(i)=current_result;
% end

% minTEC=min(ResultsVNS);
% Index=find(ResultsVNS==minTEC);
% 
% solution=SolutionsVNS{Index(1)};

% 
%%% MeshParallel
% objectiveValues=zeros(SolutionNumFromGEP,1);
% 
% for p=1:SolutionNumFromGEP
%     objectiveValues(p,1)=solution{p}.solutionRightLiftMove.obj;
% end
% 
% [~,order]=sort(objectiveValues);
% solution=solution(order,1);
% current_result=solution{1}.solutionRightLiftMove.obj;
% current_solution=solution{1};
% 
% %% Initialization
% processor=processorNum;
% p=cell(1,processor);
% for i=1:processor
%     Num=ceil(i/3);
%     p{i}=solution{Num};
% end
% 
% objectiveValues=zeros(processor,1);
% gen=1;
% 
% KnowledgeBaseMachine=KnowledgeBaseOfMachineInitialization(problemSet);
% 
% while gen<=ceil(MAXGENVNS/processor)
%     T=p;
%     LastCur_Result=current_result;
%        gen,current_result
%      if gen>1
%          parfor pi=1:processor
%              if pi==1
%                  Result1=p{1}; %#ok<PFBNS>
%                  Result2=p{processor};
%                  Result3=p{processor-1};
%                 Value=min(Result1.solutionRightLiftMove.obj,min(Result2.solutionRightLiftMove.obj,Result3.solutionRightLiftMove.obj));
%                 if Value==Result1.solutionRightLiftMove.obj
%                     T{pi}=p{1};
%                 else
%                     if Value==Result2.solutionRightLiftMove.obj
%                         T{pi}=p{processor};
%                     else  
%                         T{pi}=p{processor-1};
%                     end
%                 end
%              end
%              if pi==2
%                  Result1=p{2};
%                  Result2=p{1};
%                  Result3=p{processor};
%                 Value=min(Result1.solutionRightLiftMove.obj,min(Result2.solutionRightLiftMove.obj,Result3.solutionRightLiftMove.obj));
%                 if Value==Result1.solutionRightLiftMove.obj
%                     T{pi}=p{2};
%                 else
%                     if Value==Result2.solutionRightLiftMove.obj
%                         T{pi}=p{1};
%                     else  
%                         T{pi}=p{processor};
%                     end
%                 end
%              end
%              if pi>2
%                  Result1=p{pi};
%                  Result2=p{pi-1};
%                  Result3=p{pi-2};
%                  Value=min(Result1.solutionRightLiftMove.obj,min(Result2.solutionRightLiftMove.obj,Result3.solutionRightLiftMove.obj));
%                  if Value==Result1.solutionRightLiftMove.obj
%                      T{pi}=p{pi};
%                  else
%                      if Value==Result2.solutionRightLiftMove.obj
%                          T{pi}=p{pi-1};
%                      else
%                          T{pi}=p{pi-2};
%                      end
%                  end
%              end
%          end
%          parfor pi=1:processor
%              p{pi}=T{pi};
%          end
%      end
%      for pi=1:processor
%          p{pi}=SH_VND3(p{pi},problemSet,KnowledgeBaseMachine);
%      end
%      parfor pi=1:processor
%          objectiveValues(pi,1)=p{pi}.solutionRightLiftMove.obj;
%      end
%      if min(objectiveValues)<current_result
%          [~,order]=sort(objectiveValues);
%          p=p(1,order);
%          current_result=p{1}.solutionRightLiftMove.obj;
%          current_solution=p{1};
%          gen=1;
%      else
%          gen=gen+1;
%      end
%      if LastCur_Result<current_result
%          KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,current_solution);
%      end
%      current_result
% end
% 
% solution=current_solution;

end