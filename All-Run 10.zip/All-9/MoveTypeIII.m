function operationsSchedule=MoveTypeIII(operations,operationsSchedule,operationsScheduleAfterRightMove,LastOperationsOfJobs,Machine,MachineTime)
Movingstep=zeros(numel(operations),1);

for i=numel(operations):-1:1
    operation=operations(i);
    Movingstep(i,1)=operationsScheduleAfterRightMove(operation,4)-operationsSchedule(operation,6);
    ind=find(LastOperationsOfJobs==operation);
    if numel(ind)==0
        % if the operation is not the last operation of its job, and its next operation of the same job belongs to the same block as it
        ind2=find(operations==operation+1);
        if numel(ind2)==1
            Movingstep(i,1)=inf;
        end
    end
    EndingTimeofThisOperation=operationsSchedule(operation,6);
    durationLength=MachineTime(Machine,1)-EndingTimeofThisOperation;
    length=min(Movingstep(i,1),durationLength);
    operationsSchedule(operation,6)=operationsSchedule(operation,6)+length;
    operationsSchedule(operation,5)=operationsSchedule(operation,5)+length;
    MachineTime(Machine,1)=operationsSchedule(operation,5);
end
end