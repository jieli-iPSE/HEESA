function crossoverRate=AdaptiveCrossover(crossoverRateInitial,TEC,gen,Maxgen)
Ave=TEC.AverageResult;
Max=TEC.MaxResult;
Min=TEC.MinResult;

crossoverRate=crossoverRateInitial*(1+0.2*gen/Maxgen*Ave^2/((max(0.0001,(Max-Min)^2))+Ave^2));
end