function [solution] = ScheduleAccordingGEPDRMultiGene(problemSet,Chromosome,LastRow1,LeftRight1,LastRow2,LeftRight2,GeneNumber)

[solution] = InitializeSolution(problemSet);
[schedulingMatrics] = InitializeMatrics(problemSet);
notFinishedOperationsNumber=problemSet.problemSize.totalOperationsNumber;
finishedOperations=[];

ChromoAssignment=Chromosome{1};
ChromoSequence=Chromosome{2};

while notFinishedOperationsNumber > 0
    schedulingMatrics = FindNextTimeAndEvents(schedulingMatrics);
    
    if numel(finishedOperations)==problemSet.problemSize.totalOperationsNumber
        break;
    end
    i=1;
    while i<=size(schedulingMatrics.nextEventsList,1)
        if schedulingMatrics.nextEventsList(i,2)~=3
            if numel(find(schedulingMatrics.notFinishedOperations==schedulingMatrics.nextEventsList(i,3)))==0
                schedulingMatrics.nextEventsList(i,:)=[];
                i=i-1;
            end
        end
        i=i+1;
    end

    [schedulingMatrics] = MachineSelectionMultiGene(schedulingMatrics,problemSet,ChromoAssignment,LastRow1,LeftRight1,GeneNumber);

    schedulingMatrics.freeMachines=schedulingMatrics.freeMachines(schedulingMatrics.freeMachines~=0);
 
    for j=1:numel(problemSet.machinesSet(:,1))
        machine=j;
        waitingList=find(schedulingMatrics.machinesWaitingList(machine,:)==1);
        if numel(waitingList)>0
            selectedOperatin=SelectOperation_GEPPRMultiGene(machine,waitingList,problemSet,schedulingMatrics,ChromoSequence,LastRow2,LeftRight2,GeneNumber);
            assignableMachines=cell2mat(problemSet.operationsSet(selectedOperatin,5))';
            index=find(assignableMachines==machine);
            processingTimes=cell2mat(problemSet.operationsSet(selectedOperatin,6))';
            pcs=cell2mat(problemSet.operationsSet(selectedOperatin,8))';
            processingTime=processingTimes(index(1,1),1);
            pc=pcs(index(1,1),1);
            currentTimeofMachine=max(solution.operationsSchedule(selectedOperatin,4),max(solution.machinesStartTimes(machine,:)));
            [schedulingMatrics,solution] = StartOperationOnMachine(selectedOperatin,machine,currentTimeofMachine,processingTime,pc,schedulingMatrics,problemSet,solution);
            [schedulingMatrics] = RemoveOperationFromMachineWaitingList(selectedOperatin,machine,schedulingMatrics,processingTime);
            [schedulingMatrics] = RemoveFromNextEventsList(schedulingMatrics,selectedOperatin);
            finishedOperations(end+1,1)=selectedOperatin;
            schedulingMatrics.notFinishedOperations(schedulingMatrics.notFinishedOperations==selectedOperatin)=[];
            finishedOperations=sort(unique(finishedOperations));
            notFinishedOperationsNumber=problemSet.problemSize.totalOperationsNumber-numel(finishedOperations);
        end
    end
end
[solution] = TransformOperationsScheduleToMachinesSchedule(problemSet,solution);
[solution] = CalculateObjectiveFunctions(problemSet,solution);
end

