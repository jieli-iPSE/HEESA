function FinishTimeOfMachines=FinishTimeOnMachine(solution,problemSet)

MachineNum=problemSet.problemSize.machinesNumber;

FinishTimeOfMachines=zeros(MachineNum,2);

for j=1:MachineNum
    FinishTimeOfMachines(j,1)=j;
    AssignedOperationsOnMachine=cell2mat(solution.machinesSchedule(j,1));
    operation=AssignedOperationsOnMachine(1,end);
    FinishTimeOfMachines(j,2)=solution.operationsSchedule(operation,6);
end
FinishTimeOfMachines=sortrows(FinishTimeOfMachines,2,'descend');

end