function CPUUpperBound=CalculateCPULimitation(problemSet)
totalOperationsNumber=problemSet.problemSize.totalOperationsNumber;
% Standard=[ 10,50,100,150,200,250,300,400;10,150,200,250,300,350,400,450];
Standard=[ 10,50,100,150,200,250,300,400;10,200,250,300,350,400,450,500];
for i=1: size(Standard,2)
   if Standard(1,i)>totalOperationsNumber
       CPUUpperBound=Standard(2,i);
       break;
   end
end
end