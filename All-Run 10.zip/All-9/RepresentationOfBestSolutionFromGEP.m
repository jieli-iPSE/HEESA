function [solution]=RepresentationOfBestSolutionFromGEP(solution,problemSet)

OperationNum=problemSet.problemSize.totalOperationsNumber;
MachineNum=problemSet.problemSize.machinesNumber;
JobNum=problemSet.problemSize.jobsNumber;
NumberofOperationInJob=zeros(JobNum,2);
for i=1:JobNum
    NumberofOperationInJob(i,1)=i;    
    NumberofOperationInJob(i,2)=numel(find(solution.operationsSchedule(:,2)==i));
end


solution.OperationSequencingList=zeros(OperationNum,4);
% save operation number before and after idle time
solution.IdlePositionOnMachine=cell(1,2*MachineNum);

OperationSchedule=solution.operationsSchedule;
OperationSchedule=sortrows(OperationSchedule,5);

for i=1:OperationNum
    solution.OperationSequencingList(i,1)=OperationSchedule(i,2);
    solution.OperationSequencingList(i,2)=OperationSchedule(i,3);
    solution.OperationSequencingList(i,3)=OperationSchedule(i,7);
    solution.OperationSequencingList(i,4)=OperationSchedule(i,1);
end

machineSchedule=solution.machinesSchedule;
OperationSchedule=solution.operationsSchedule;
for j=1:MachineNum
    if numel(machineSchedule{j,1})>0
        solution.IdlePositionOnMachine{1,(2*j-1)}=0;
        operationIndex=machineSchedule{j,1}(1);                
        operation=[OperationSchedule(operationIndex,2),OperationSchedule(operationIndex,3)];
        solution.IdlePositionOnMachine{1,(2*j)}=operation;  
        idelnum=1;
        for i=1:(numel(machineSchedule{j,1})-1)
            operationIndex1=machineSchedule{j,1}(i);
            operationIndex2=machineSchedule{j,1}(i+1);
            idletime=OperationSchedule(operationIndex2,5)-OperationSchedule(operationIndex1,6);
            if idletime>0
                idelnum=idelnum+1;
                operation1=[OperationSchedule(operationIndex1,2),OperationSchedule(operationIndex1,3)];
                operation2=[OperationSchedule(operationIndex2,2),OperationSchedule(operationIndex2,3)];
                solution.IdlePositionOnMachine{idelnum,(2*j-1)}=operation1;
                solution.IdlePositionOnMachine{idelnum,2*j}=operation2;
            end
        end
        operationIndex=machineSchedule{j,1}(end);                
        operation=[OperationSchedule(operationIndex,2),OperationSchedule(operationIndex,3)];
        solution.IdlePositionOnMachine{idelnum+1,(2*j-1)}=operation;  
        solution.IdlePositionOnMachine{idelnum+1,(2*j)}=0;  
    end 
end

end