function [schedulingMatrics] = InitializeMatrics(problemSet)
    
    jobsSet=problemSet.jobsSet;
    machinesSet=problemSet.machinesSet;
    operationsSet=problemSet.operationsSet;
    problemSize=problemSet.problemSize;
    jobsNumber=problemSize.jobsNumber;
    machinesNumber=problemSize.machinesNumber;
    totalOperationsNumber=problemSize.totalOperationsNumber;
    notFinishedOperations=cell2mat(operationsSet(:,1));
    machinesWaitingList=zeros(machinesNumber,totalOperationsNumber);
    machinesWaitingListLoad=zeros(machinesNumber,1);
    machinesStartTimes=zeros(machinesNumber,2);
    machinesNextFailureTime=zeros(machinesNumber,1);
    freeMachines=cell2mat(machinesSet(:,1));
    recentlyReleasedOperations=[];
    recentlyAssignedOperations=[];
    recentlyFinishedOperations=[];
    recentlyAssignedMachines=[];
    recentlyStartedMachines=[];
    recentlyFinishedmachines=[];
    %machinesWaitingList={};
    nextEventsList=zeros(jobsNumber,3);
    for i=1:jobsNumber
       nextEventsList(i,1)=cell2mat(jobsSet(i,2));
       nextEventsList(i,2)=1;
       nextEventsList(i,3)=jobsSet{i,5}(1);
    end
    schedulingMatrics.notFinishedOperations=notFinishedOperations;
    schedulingMatrics.recentlyReleasedOperations=recentlyReleasedOperations;
    schedulingMatrics.recentlyAssignedOperations=recentlyAssignedOperations;
    schedulingMatrics.recentlyFinishedOperations=recentlyFinishedOperations;
    schedulingMatrics.recentlyAssignedMachines=recentlyAssignedMachines;
    schedulingMatrics.recentlyStartedMachines=recentlyStartedMachines;
    schedulingMatrics.recentlyFinishedmachines=recentlyFinishedmachines;
    schedulingMatrics.freeMachines=freeMachines;
    schedulingMatrics.machinesWaitingList=machinesWaitingList;
    schedulingMatrics.machinesWaitingListLoad=machinesWaitingListLoad;
    schedulingMatrics.machinesStartTimes=machinesStartTimes;
    schedulingMatrics.machinesNextFailureTime=machinesNextFailureTime;
    schedulingMatrics.nextEventsList=nextEventsList;
    
end

