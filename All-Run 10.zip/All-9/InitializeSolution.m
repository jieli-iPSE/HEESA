function [solution] = InitializeSolution(problemSet)
    
    operationsSchedule=zeros(problemSet.problemSize.totalOperationsNumber,7);
    operationIndex=1;
    for i=1:problemSet.problemSize.jobsNumber
        for j=1:problemSet.jobsSet{i,4}
            operationsSchedule(operationIndex,1)=operationIndex;
            operationsSchedule(operationIndex,2)=i;
            operationsSchedule(operationIndex,3)=j;
            operationIndex=operationIndex+1;
        end
    end

    solution.operationsSchedule=operationsSchedule;
    solution.machinesSchedule=[];
    solution.order=[];
    %solution.machinesGaps=[];
    %solution.criticalOperations=[];
    %solution.criticalBlocks=[];
    
    %solution.dominationSet=[];
    %solution.dominatedSet=[];
    %solution.rank=[];


    machinesStartTimes=zeros(problemSet.problemSize.machinesNumber,2);
    solution.machinesStartTimes=machinesStartTimes;
   
end

