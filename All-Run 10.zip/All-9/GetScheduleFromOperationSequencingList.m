function solution=GetScheduleFromOperationSequencingList (solution,problemSet)
OperationSequencingList=solution.OperationSequencingList;
OperationNum=problemSet.problemSize.totalOperationsNumber;
MachineNum=problemSet.problemSize.machinesNumber;
JobNum=problemSet.problemSize.jobsNumber;

FirstOperationsOfJobs=zeros(JobNum,1);
LastOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
  FirstOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(1);
  LastOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(end);
end

operationsSchedule=solution.operationsSchedule;
operationsSchedule(:,4:6)=0;
MachineTime=zeros(MachineNum,1);
for i=1:OperationNum
    operation=OperationSequencingList(i,4);
    machine=OperationSequencingList(i,3);
    AvailableMachines=cell2mat(problemSet.operationsSet(operation,5));
    IndexofMachine=find(AvailableMachines==machine);
    processingTime=problemSet.operationsSet{operation,6}(IndexofMachine(1));
    
    ind=find(FirstOperationsOfJobs==operation);
    if numel(ind)==1
        startingTime=MachineTime(machine,1);
    else
        startingTime=max(MachineTime(machine,1),operationsSchedule(operation,4));
    end
    operationsSchedule(operation,5)=startingTime;
    operationsSchedule(operation,6)=startingTime+processingTime;
   
    ind=find(LastOperationsOfJobs==operation);
    if numel(ind)==0
        operationsSchedule(operation+1,4)=startingTime+processingTime;
    end
    MachineTime(machine,1)=startingTime+processingTime;
end
solution.operationsSchedule=operationsSchedule;
end
