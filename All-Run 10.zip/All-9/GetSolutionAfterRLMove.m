function SolutionV=GetSolutionAfterRLMove(solution,problemSet)

SolutionV.solutionEarliestStartingStrategy=solution;

solutionAfterLRMove =RMLM(solution,problemSet);

SolutionV.solutionRightLiftMove=solutionAfterLRMove;

end