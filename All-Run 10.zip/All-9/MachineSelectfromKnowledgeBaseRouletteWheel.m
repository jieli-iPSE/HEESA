function MachineSelectedFromKnowledgeBase=MachineSelectfromKnowledgeBaseRouletteWheel(KnowledgeBaseMachine)

OperationNumWithMultipleMachine=size(KnowledgeBaseMachine,1);
MachineNum=size(KnowledgeBaseMachine,2)-1;

MachineSelectedFromKnowledgeBase=zeros(OperationNumWithMultipleMachine,2);
%% Accumlation 
for i=1:OperationNumWithMultipleMachine
    MachineNumAvailbale=find(KnowledgeBaseMachine(i,:)>0);
    summation=0;
    Num=1;
    for j=2:MachineNum+1
        if KnowledgeBaseMachine(i,j)>0
            KnowledgeBaseMachine(i,j)=KnowledgeBaseMachine(i,j)+summation;
            summation=summation+KnowledgeBaseMachine(i,j);
            
            if Num==size(MachineNumAvailbale,2)-1
                KnowledgeBaseMachine(i,j)=1;
            end
            Num=Num+1;
        end
    end
end

for i=1:OperationNumWithMultipleMachine        
    operation=KnowledgeBaseMachine(i,1);
    MachineSelectedFromKnowledgeBase(i,1)=operation;
    Index=rand(1);
    for j=2:MachineNum+1
%         j,KnowledgeBaseMachine(i,j),Index
        
       if  Index<=KnowledgeBaseMachine(i,j)
           MachineSelectedFromKnowledgeBase(i,2)=j-1;
           break;
       end
    end
end

end
