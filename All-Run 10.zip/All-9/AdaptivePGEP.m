function [Result,CPU] = AdaptivePGEP(IndexofProblem,benchmark,nPop,maxIteration,headSize,GeneNumber,functionsNumber,elementsSize,crossoverRateInitial,mutationRateInitial,MAXGENVNS)
%%
% Variable: 1:it idle time, 2: pt  processing time, 3: pc cutting power, 4: pu unload power 5: nr unschuduled opearion
% Operation: 1: + 2: - 3:/ 4: * 5:Q
%% Data of the target problem
[problemSet] = FJSSPReadProblemSet(benchmark);

%% Initialization
tic
GeneSize=headSize*2+1;

pop=cell(nPop,1);

for i=1:nPop
    [chromosome] = CreateRandomChromosomeMultiCell(headSize,GeneSize,GeneNumber,functionsNumber,elementsSize);
    pop{i}.chromosome=chromosome;
end

%% calculate fitness value of one chromosome - TEC
parfor i=1:nPop

    chromosome=pop{i}.chromosome;
    
    ChromoSequence=chromosome{1};
    ChromoAssignment=chromosome{2};
    %% Generating Matrix expression the mathematical expression 
    [LastRow1,LeftRight1] = DecodeChromosomeMultiGene(ChromoSequence,headSize,GeneNumber);
    [LastRow2,LeftRight2] = DecodeChromosomeMultiGene(ChromoAssignment,headSize,GeneNumber);
    %% Calculating TEC
    [solution] = ScheduleAccordingGEPDRMultiGene(problemSet,chromosome,LastRow1,LeftRight1,LastRow2,LeftRight2,GeneNumber);
    
    pop{i}.obj = solution.obj;
    pop{i}.Cmax = solution.Cmax;
    pop{i}.OnOffStEng = solution.OnOffStEng;
    pop{i}.PtPc = solution.PtPc;
    pop{i}.operationsSchedule = solution.operationsSchedule;
end

objectiveValues=zeros(numel(pop),1);

for i=1:numel(pop)
    objectiveValues(i,1)=pop{i}.obj;
end
[~,order]=sort(objectiveValues);
pop=pop(order,1);

%% TEC results in each generation saved to calculate the crossover/mutation rate which is adaptive
TEC=TECResultForGeneration(pop,nPop);


%% Best elites in GEP iteration would be saved to input into VNS, the number of elite is related to the number of cores (i.e. number of processors in Parallel VNS)
ProcessorNum=24;
NumElite=ProcessorNum;
BestIndividulStored=cell(NumElite,1);
ObjsStored=ones(NumElite,1)*inf;
[BestIndividulStored,ObjsStored]=UpdateStoredDate(pop,BestIndividulStored,ObjsStored);

%% objs matrix save the best TEC result in each generation of GEP
objs=zeros(maxIteration,1);
objs(1,1)=pop{1}.obj;

%% GEP Iteration 
for it=1:maxIteration
    
    %% crossover 
    crossoverRate=AdaptiveCrossover(crossoverRateInitial,TEC,it,maxIteration);
    crossoverNumber=round(crossoverRate*nPop);
    crossoverPop=cell(crossoverNumber,1);
    
    for i=1:ceil(crossoverNumber/2)
        index1=randi([1 nPop],1,1);
        index2=randi([1 nPop],1,1);
        [selectedIndex1] = GEPTournamentSelection(index1,index2,pop);
        
        index1=randi([1 nPop],1,1);
        index2=randi([1 nPop],1,1);
        [selectedIndex2] = GEPTournamentSelection(index1,index2,pop);
        
        parent1=pop{selectedIndex1};
        parent2=pop{selectedIndex2};
        
        [child1,child2] = GEPCrossoverMultiGene(parent1,parent2,GeneNumber,GeneSize);

        crossoverPop{2*i-1}.chromosome=child1.chromosome;
        crossoverPop{2*i}.chromosome=child2.chromosome;
    end
    
    %% mutation
    mutationRate=Adaptivemutation(mutationRateInitial,TEC,it);
    mutationNumber=round(mutationRate*nPop);
    mutationPop=cell(mutationNumber,1);
    
    for i=1:mutationNumber
        index1=randi([1 nPop],1,1);
        index2=randi([1 nPop],1,1);
        [selectedIndex] = GEPTournamentSelection(index1,index2,pop);
        parent=pop{selectedIndex};

        [child] = GEPMutationMultiGene(parent,headSize,functionsNumber,elementsSize,GeneNumber,GeneSize);
     
        mutationPop{i}.chromosome=child.chromosome;
    end
    
    
    %% transposition
%     TranspositionRate=max(0,1-crossoverRate-mutationRate);
    TranspositionRate=0;
    TranspositionNumber=round(TranspositionRate*nPop);
    TranspositionPop=cell(TranspositionNumber,1);
    for i=1:TranspositionNumber
        index1=randi([1 nPop],1,1);
        index2=randi([1 nPop],1,1);
        [selectedIndex] = GEPTournamentSelection(index1,index2,pop);
        parent=pop{selectedIndex};
        
        [child] = GEPISTranspositionMultiGene(parent,headSize,GeneNumber,GeneSize);
        TranspositionPop{i}.chromosome=child.chromosome;
    end
    
    %% individuals from offspring 
    newPop=[crossoverPop;mutationPop;TranspositionPop];
    SizeOfNewPop=TranspositionNumber+mutationNumber+ceil(crossoverNumber/2)*2;
    
    parfor i=1:SizeOfNewPop

        chromosome=newPop{i}.chromosome;
        
        ChromoSequence=chromosome{1};
        ChromoAssignment=chromosome{2};
        [LastRow1,LeftRight1] = DecodeChromosomeMultiGene(ChromoSequence,headSize,GeneNumber);
        [LastRow2,LeftRight2] = DecodeChromosomeMultiGene(ChromoAssignment,headSize,GeneNumber);
        [solution] = ScheduleAccordingGEPDRMultiGene(problemSet,chromosome,LastRow1,LeftRight1,LastRow2,LeftRight2,GeneNumber);
        
        newPop{i}.obj = solution.obj;
        newPop{i}.Cmax = solution.Cmax ;
        newPop{i}.OnOffStEng = solution.OnOffStEng ;
        newPop{i}.PtPc = solution.PtPc;
        newPop{i}.operationsSchedule = solution.operationsSchedule;
    end
    
    %% individuals from last generation 
    for i=1:round(0.8*nPop)
        newPop{end+1}=pop{i}; %#ok<AGROW>
    end
    
    %% population size= npop
    objectiveValues=zeros(numel(newPop),1);
    for i=1:numel(newPop)
        objectiveValues(i,1)=newPop{i}.obj;
    end
    [~,order]=sort(objectiveValues);
    newPop=newPop(order,1);

    pop=newPop(1:nPop);
    
    %% save best TEC for each generation
    
    objs(it,1)=pop{1}.obj;
    %% save TEC min, max, avg
    TEC=TECResultForGeneration(pop,nPop);
    
    %% save elite for iteration
    [BestIndividulStored,ObjsStored]=UpdateStoredDate(pop,BestIndividulStored,ObjsStored);
end

%% Result for GEP 
SolutionGEP=pop{1};



%% Generate machinesSchedule and OperationSequencingList for solutions in the BestIndividulStored

for i=1:size(BestIndividulStored,1)
    if isempty(BestIndividulStored{i})==1
        BestIndividulStored{i}=BestIndividulStored{1};
    else
        BestIndividulStored{i}=TransformOperationsScheduleToMachinesSchedule(problemSet,BestIndividulStored{i});
        BestIndividulStored{i}=RepresentationOfBestSolutionFromGEP(BestIndividulStored{i},problemSet);
        BestIndividulStored{i}=GetSolutionAfterRLMove(BestIndividulStored{i},problemSet);
    end
end
CPUGEP=toc;
%% VNS 

tic

[SolutionVNS]=PVNS_IndependentPUpdateKnowledge(BestIndividulStored,problemSet,MAXGENVNS,ProcessorNum,CPUGEP);

CPUVNS=toc;


%% Results

Result=[SolutionGEP.obj,SolutionVNS.solutionRightLiftMove.obj]

CPU=[CPUGEP,CPUVNS]

end

