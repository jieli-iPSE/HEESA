function [solution] = CreateMachinesSchedule(problemSet,solution)
    
    operationNum=problemSet.problemSize.totalOperationsNumber;
    solution.machinesSchedule=cell(problemSet.problemSize.machinesNumber,1);
    for i=1:operationNum
        operation=solution.OperationSequencingList(i,4);
        machine=solution.OperationSequencingList(i,3);
        index=numel(solution.machinesSchedule{machine,1})+1;
        solution.machinesSchedule{machine,1}(index)=operation;
        %problemSet.machinesSchedule{machine,2}=[problemSet.machinesSchedule{machine,2} operation];
    end
end

