function OnOffStandbyEnergy=OnOffStandbyEnergyOfMachines(problemSet,solution)

operationsAssignmentResults=solution.operationsSchedule;
machinesCount=problemSet.problemSize.machinesNumber;
OnOffStanbyEnergyOfMachines=zeros(machinesCount,1);

OnOffStandbyEnergy=zeros(machinesCount,2);

for i=1:machinesCount
    thismachinetable=operationsAssignmentResults(operationsAssignmentResults(:,7)==i,:);
    [~,o]=sort(thismachinetable(:,5));
    thismachinetable=thismachinetable(o,:);
    assignedoperationscount=numel(solution.machinesSchedule{i,1});
    Pu=problemSet.machinesSet{i,5};
    Eo=problemSet.machinesSet{i,6};
    for j=1:assignedoperationscount-1
        if thismachinetable(j+1,5)>thismachinetable(j,6)
                it=thismachinetable(j+1,5)-thismachinetable(j,6);
                OnOffStanbyEnergyOfMachines(i)=min(Eo,it*Pu)+OnOffStanbyEnergyOfMachines(i);
        end
    end
    OnOffStandbyEnergy(i,1)=i;
    OnOffStandbyEnergy(i,2)=OnOffStanbyEnergyOfMachines(i);
end
OnOffStandbyEnergy=sortrows(OnOffStandbyEnergy,2,'descend');
end