function [schedulingMatrics] = RemoveFromNextEventsList(schedulingMatrics,operation)
    [rowofoperation,~]=find(schedulingMatrics.nextEventsList(:,3)==operation);
    i=1;
    while i<=rowofoperation
        if schedulingMatrics.nextEventsList(rowofoperation,2)~=3
            schedulingMatrics.nextEventsList(rowofoperation,:)=[];
            i=i-1;
        end
        [rowofoperation,~]=find(schedulingMatrics.nextEventsList(:,3)==operation);
        i=i+1;
    end

end

