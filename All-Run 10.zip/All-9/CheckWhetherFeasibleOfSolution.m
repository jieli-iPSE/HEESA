function Success=CheckWhetherFeasibleOfSolution(OperationSequence,problemSet)
Success=1;
JobNum=problemSet.problemSize.jobsNumber;

for i=1:JobNum
    OperationNumOfJobI=cell2mat(problemSet.jobsSet(i,4));    
    for j=1:(OperationNumOfJobI-1)
        jj=j+1;
        position1=find(OperationSequence(:,1)==i & OperationSequence(:,2)==j);
        position2=find(OperationSequence(:,1)==i & OperationSequence(:,2)==jj);
        if position1>position2
            Success=0;
            break;
        end
    end
    if Success==0
        break;
    end
end
end