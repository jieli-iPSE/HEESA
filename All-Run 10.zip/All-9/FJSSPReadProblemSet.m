function [problemSet] = FJSSPReadProblemSet(benchmark)
    problemSize=struct('jobsNumber',{0},'totalOperationsNumber',{1},'machinesNumber',{1},'indirectFraction',{1});
    problemSize.jobsNumber=benchmark(1,1);
    problemSize.totalOperationsNumber=sum(benchmark(2:problemSize.jobsNumber+1,3));
    problemSize.machinesNumber=benchmark(1,2);

    jobsSet=cell(problemSize.jobsNumber,6);  
    machinesSet=cell(problemSize.machinesNumber,6);
    for i=1:problemSize.machinesNumber
        machinesSet{i,1}=i;
        machinesSet{i,2}=0;
        machinesSet{i,5}=benchmark(problemSize.jobsNumber+2,i);
        machinesSet{i,6}=benchmark(problemSize.jobsNumber+3,i);
    end
    operationsSet=cell(problemSize.totalOperationsNumber,8);
    %operationsSchedule=zeros(problemSize.totalOperationsNumber,7);
    operationIndex=1;
    for i=2:problemSize.jobsNumber+1
        jobsSet{i-1,1}=i-1;
        jobsSet{i-1,2}=benchmark(i,1);
        jobsSet{i-1,3}=benchmark(i,2);
        jobsSet{i-1,4}=benchmark(i,3);        
        orderIndex=1;
        c=3;
        jobTotalProcessingTime=0;
        for j=1:jobsSet{i-1,4}
            c=c+1;
            jobsSet{i-1,5}(j)=operationIndex;
            operationsSet{operationIndex,1}=operationIndex;
            operationsSet{operationIndex,2}=i-1;
            operationsSet{operationIndex,3}=orderIndex;
            %operationsSchedule(operationIndex,1)=operationIndex;
            %operationsSchedule(operationIndex,2)=i-1;
            %operationsSchedule(operationIndex,3)=orderIndex;
            operationsSet{operationIndex,4}=benchmark(i,c);
            opTotalProcessingTime=0;
            for k=1:benchmark(i,c)
                operationsSet{operationIndex,5}(k)=benchmark(i,c+1);
                machinesSet{benchmark(i,c+1),2}=machinesSet{benchmark(i,c+1),2}+1;
                machinesSet{benchmark(i,c+1),3}(machinesSet{benchmark(i,c+1),2})=operationIndex;
                operationsSet{operationIndex,6}(k)=benchmark(i,c+2);
                machinesSet{benchmark(i,c+1),4}(machinesSet{benchmark(i,c+1),2})=benchmark(i,c+2);
                opTotalProcessingTime=opTotalProcessingTime+benchmark(i,c+2);
                operationsSet{operationIndex,8}(k)=benchmark(i,c+3);
                c=c+3;
            end
            operationsSet{operationIndex,7}=opTotalProcessingTime/operationsSet{operationIndex,4};
            jobTotalProcessingTime=opTotalProcessingTime/operationsSet{operationIndex,4}+jobTotalProcessingTime;
            operationIndex=operationIndex+1;
            orderIndex=orderIndex+1;
        end
        jobsSet{i-1,6}=jobTotalProcessingTime;
    end

    
    problemSet.problemSize=problemSize;
    problemSet.jobsSet=jobsSet; 
    problemSet.operationsSet=operationsSet; 
    problemSet.machinesSet=machinesSet;
        problemSet.indirectFraction=benchmark(problemSize.jobsNumber+4,1);
    %problemSet.operationsSchedule=operationsSchedule;
    %problemSet.machinesSchedule=[];
    %problemSet.order=[];
end

