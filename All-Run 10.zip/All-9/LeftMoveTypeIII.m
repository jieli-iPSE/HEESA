function operationsSchedule=LeftMoveTypeIII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine)
Movingstep=zeros(numel(operations),1);

for i=1:numel(operations)
    operation=operations(i);
    Movingstep(i,1)=operationsSchedule(operation,5)-operationsScheduleAfterLeftMove(operation,4);
    
    ind=find(FirstOperationsOfJobs==operation);
    if numel(ind)==0
        % if the operation in not the last operation of its job, and its next operation of the same job belongs to the same block as it
        ind2=find(operations==operation-1);
        if numel(ind2)==1
            Movingstep(i,1)=inf;
        end
    end
    StartingTimeOfThisOperation=operationsSchedule(operation,5);

    durationLength=StartingTimeOfThisOperation-MachineTime(Machine,1);
    Length=min(min(Movingstep(i,1)),durationLength);
    operationsSchedule(operation,6)=operationsSchedule(operation,6)-Length;
    operationsSchedule(operation,5)=operationsSchedule(operation,5)-Length;
    MachineTime(Machine,1)=operationsSchedule(operation,6);
end
end