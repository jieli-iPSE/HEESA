function solution=PVNS_meshP(solution,problemSet,MAXGENVNS,processorNum)

%% there are multiple solutions saved in solution, each solution is accepted by one processor, number of solutions = processorNum/3;
%% find current best solution and MIN TEC
SolutionNumFromGEP=size(solution,1);
objectiveValues=zeros(SolutionNumFromGEP,1);

for p=1:SolutionNumFromGEP
    objectiveValues(p,1)=solution{p}.solutionRightLiftMove.obj;
end

[~,order]=sort(objectiveValues);
solution=solution(order,1);
current_result=solution{1}.solutionRightLiftMove.obj;
current_solution=solution{1};

%% Initialization
processor=processorNum;
p=cell(1,processor);
for i=1:processor
    Num=ceil(i/3);
    p{i}=solution{Num};
end

objectiveValues=zeros(processor,1);
gen=1;

KnowledgeBaseMachine=KnowledgeBaseOfMachineInitialization(problemSet);


MAXGENVNS=5000

while gen<=ceil(MAXGENVNS/processor)
    T=p;
    LastCur_Result=current_result;
       gen,current_result
     if gen>1
         parfor pi=1:processor
             if pi==1
                 Result1=p{1}; %#ok<PFBNS>
                 Result2=p{processor};
                 Result3=p{processor-1};
                Value=min(Result1.solutionRightLiftMove.obj,min(Result2.solutionRightLiftMove.obj,Result3.solutionRightLiftMove.obj));
                if Value==Result1.solutionRightLiftMove.obj
                    T{pi}=p{1};
                else
                    if Value==Result2.solutionRightLiftMove.obj
                        T{pi}=p{processor};
                    else  
                        T{pi}=p{processor-1};
                    end
                end
             end
             if pi==2
                 Result1=p{2};
                 Result2=p{1};
                 Result3=p{processor};
                Value=min(Result1.solutionRightLiftMove.obj,min(Result2.solutionRightLiftMove.obj,Result3.solutionRightLiftMove.obj));
                if Value==Result1.solutionRightLiftMove.obj
                    T{pi}=p{2};
                else
                    if Value==Result2.solutionRightLiftMove.obj
                        T{pi}=p{1};
                    else  
                        T{pi}=p{processor};
                    end
                end
             end
             if pi>2
                 Result1=p{pi};
                 Result2=p{pi-1};
                 Result3=p{pi-2};
                 Value=min(Result1.solutionRightLiftMove.obj,min(Result2.solutionRightLiftMove.obj,Result3.solutionRightLiftMove.obj));
                 if Value==Result1.solutionRightLiftMove.obj
                     T{pi}=p{pi};
                 else
                     if Value==Result2.solutionRightLiftMove.obj
                         T{pi}=p{pi-1};
                     else
                         T{pi}=p{pi-2};
                     end
                 end
             end
         end
         parfor pi=1:processor
             p{pi}=T{pi};
         end
     end
     for pi=1:processor
         p{pi}=SH_VND3(p{pi},problemSet,KnowledgeBaseMachine);
     end
     parfor pi=1:processor
         objectiveValues(pi,1)=p{pi}.solutionRightLiftMove.obj;
     end
     if min(objectiveValues)<current_result
         [~,order]=sort(objectiveValues);
         p=p(1,order);
         current_result=p{1}.solutionRightLiftMove.obj;
         current_solution=p{1};
         gen=1;
     else
         gen=gen+1;
     end
     if LastCur_Result<current_result
         KnowledgeBaseMachine=KnowledgeBaseOfMachineUpdate(KnowledgeBaseMachine,current_solution);
     end
     current_result
end

solution=current_solution;

end