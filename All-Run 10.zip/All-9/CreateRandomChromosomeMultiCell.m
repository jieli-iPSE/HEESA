function [Chromosome] = CreateRandomChromosomeMultiCell(headSize,GeneSize,GeneNumber,functionsNumber,elementsSize)
%% Chromosome First chromosome is for sequence, Second is for assignment
Chromosome=cell(2,1);
%headSize=5;
ElementNum=elementsSize;
for i=1:2
    %% Generate chromosome with multiple gene
    ChromosomeOfGenes=cell(GeneNumber+1,1);
    %%%% Note: the last gene is linking function
    for j=1:GeneNumber+1
        chromosome=zeros(2,GeneSize);
        if j==GeneNumber
            elementsSize=GeneNumber;
        end
        for c=1:GeneSize
            if c==1
                rnd=randi([1,functionsNumber],1,1);
                %chromosome(1,i)=char(functionsSet(1,rnd));
                chromosome(1,c)=rnd;
                chromosome(2,c)=1;
            elseif 1<c && c<=headSize
                rnd1=round(randi([0,1],1,1));
                if rnd1==1
                    rnd=randi([1,functionsNumber],1,1);
                    %chromosome(1,i)=char(functionsSet(1,rnd));
                    chromosome(1,c)=rnd;
                    chromosome(2,c)=1;
                else
                    rnd=randi([1,elementsSize],1,1);
                    %chromosome(1,i)=char(elementsSet(1,rnd));
                    chromosome(1,c)=rnd;
                    chromosome(2,c)=2;
                end
            elseif headSize<c && c<=GeneSize
                rnd=randi([1,elementsSize],1,1);
                %chromosome(1,i)=char(elementsSet(1,rnd));
                %chromosomeDecoding(i,1)=char(elementsSet(1,rnd));
                chromosome(1,c)=rnd;
                chromosome(2,c)=2;
            end
        end
        elementsSize=ElementNum;
        ChromosomeOfGenes{j}=chromosome;
    end
    
    %%% elementsSize in the last gene is GeneNum
    Chromosome{i}=ChromosomeOfGenes;   
end
end

