function [child]=GEPISTranspositionMultiGene(parent,headSize,GeneNumber,GeneSize)
child.chromosome=cell(2,1);
for j=1:2
    chromosome=parent.chromosome{j};
    chromosomeChild=cell(GeneNumber+1,1);
    for i=1:GeneNumber+1
        Gene=chromosome{i};
        PositionofTransposon1=randi([4,GeneSize-1],1,1);
        PositionofTransposon2=randi([PositionofTransposon1,GeneSize],1,1);
        PositionofInsertion=randi([2,min(PositionofTransposon1,headSize)-2],1,1);
        
        LengthofTransposon=PositionofTransposon2-PositionofTransposon1+1;
        
        Transposon=Gene(1:2,PositionofTransposon1:PositionofTransposon2);
        if PositionofInsertion+1+LengthofTransposon<=headSize
            Gene(1:2,PositionofInsertion+1+LengthofTransposon)=Gene(1:2,PositionofInsertion+1);
        else
            if Gene(2,PositionofInsertion+1)==2
                Gene(1:2,PositionofInsertion+1+LengthofTransposon)=Gene(1:2,PositionofInsertion+1);
            end
        end
        Gene(1:2,PositionofInsertion+1:PositionofInsertion+LengthofTransposon)=Transposon;
        chromosomeChild{i}=Gene;
    end
    child.chromosome{j}=chromosomeChild;
end
end