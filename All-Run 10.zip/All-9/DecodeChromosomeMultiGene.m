function [LastRow,LeftRight] = DecodeChromosomeMultiGene(Chromosome,headSize,GeneNumber)
LeftRight=cell(GeneNumber+1,1);
LastRow=cell(GeneNumber+1,1);

for gene=1:(GeneNumber+1)
    GeneSize=2*headSize+1;
    leftRight=zeros(GeneSize,6);
    rows=[];
    rightElement=0;
    chromosome=Chromosome{gene};
    for i=1:GeneSize
        e=chromosome(2,i);
        %if ismember(e,functionsSet) && e~='q'
        if e==1 && chromosome(1,i)~=5
            leftElement=max(i,rightElement)+1;
            %new
            leftRight(i,1)=chromosome(1,i);
            leftRight(i,2)=leftElement;
            rightElement=leftElement+1;
            leftRight(i,3)=rightElement;
            rows(end+1,1)=i;
        %elseif ismember(e,functionsSet) && e=='q'
        elseif e==1 && chromosome(1,i)==5
            leftElement=max(i,rightElement)+1;
            %new
            leftRight(i,1)=chromosome(1,i);
            leftRight(i,2)=leftElement;
            rightElement=leftElement;
            rows(end+1,1)=i;
        end
    end
    numberOfRows=numel(rows);
    lastRowIndex=1;
    for i=1:numberOfRows-1
        row=rows(i,1);
        if leftRight(row,3)==0
            previousElement=leftRight(row,2);
        else
            previousElement=leftRight(row,3);
        end
        nextRow=rows(i+1,1);
        nextElement=leftRight(nextRow,2);
        if nextElement-previousElement>1
            break;
        else
            lastRowIndex=lastRowIndex+1;
        end
    end
    lastRow=rows(lastRowIndex,1);
    LeftRight{gene}=leftRight;
    LastRow{gene}=lastRow;
end
end

