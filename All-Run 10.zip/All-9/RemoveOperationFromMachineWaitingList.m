function [schedulingMatrics] = RemoveOperationFromMachineWaitingList(operation,machine,schedulingMatrics,processingTime)
    schedulingMatrics.machinesWaitingList(machine,operation)=0;
    schedulingMatrics.machinesWaitingListLoad=schedulingMatrics.machinesWaitingListLoad-processingTime;
end

