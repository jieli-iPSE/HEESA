function [schedulingMatrics] = LeastWaitingTimeAssignment(schedulingMatrics,problemSet,currentTime)
    recentlyReleasedOperationsNumber=numel(schedulingMatrics.recentlyReleasedOperations);
    
    schedulingMatrics.recentlyAssignedOperations=[];
    schedulingMatrics.recentlyAssignedMachines=[];
    
    for i=1:recentlyReleasedOperationsNumber
        operation=schedulingMatrics.recentlyReleasedOperations(i,1);
        tempAssignableMachinesList=cell2mat(problemSet.operationsSet(operation,5))';
        tempAssignableMachinesProcessingTimes=cell2mat(problemSet.operationsSet(operation,6))';
        numberOfAssignableMachines=numel(tempAssignableMachinesList);
        tempAssignableMachinesLoad=zeros(numberOfAssignableMachines,1);
        for j=1:numberOfAssignableMachines
            %w=0;w1=0;w2=0;w3=0;
            machine=tempAssignableMachinesList(j,1);
            if ismember(machine,schedulingMatrics.freeMachines)
                w1=0;
            else
                w1=currentTime-schedulingMatrics.machinesStartTimes(machine,2);
            end
            w2=schedulingMatrics.machinesWaitingListLoad(machine,1);
            w3=tempAssignableMachinesProcessingTimes(j,1);
            w=w1+w2+w3;
            tempAssignableMachinesLoad(j,1)=w;
        end
        [~,index]=min(tempAssignableMachinesLoad);
        machine=tempAssignableMachinesList(index,1);
        schedulingMatrics.machinesWaitingList(machine,operation)=1;
        schedulingMatrics.recentlyAssignedOperations(end+1,1)=operation;
        schedulingMatrics.recentlyAssignedMachines(end+1,1)=machine;
    end


end

