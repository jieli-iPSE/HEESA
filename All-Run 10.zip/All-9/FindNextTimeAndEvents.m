function [schedulingMatrics] = FindNextTimeAndEvents(schedulingMatrics)
    
    schedulingMatrics.recentlyReleasedOperations=[];
    schedulingMatrics.recentlyFinishedOperations=[];
    schedulingMatrics.recentlyFinishedmachines=[];
    schedulingMatrics.recentlyStartedMachines=[];
    schedulingMatrics.recentlyAssignedMachines=[];
    schedulingMatrics.recentlyFinishedmachines=[];
    nextTime = min(schedulingMatrics.nextEventsList(:,1));
    [rowSize, ~] = size(schedulingMatrics.nextEventsList);
    for i=1:rowSize
        if schedulingMatrics.nextEventsList(i,1)==nextTime
            if schedulingMatrics.nextEventsList(i,2)==2
                schedulingMatrics.recentlyFinishedOperations(end+1,1)=schedulingMatrics.nextEventsList(i,3);
            elseif schedulingMatrics.nextEventsList(i,2)==1
                schedulingMatrics.recentlyReleasedOperations(end+1,1)=schedulingMatrics.nextEventsList(i,3);
            else
                schedulingMatrics.recentlyFinishedmachines(end+1,1)=schedulingMatrics.nextEventsList(i,3);
                schedulingMatrics.freeMachines(end+1,1)=schedulingMatrics.nextEventsList(i,3);
                schedulingMatrics.freeMachines=sort(schedulingMatrics.freeMachines);
            end                        
        end
    end
end

