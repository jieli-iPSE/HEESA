function SolutionLeftMove =LeftMove(solution,problemSet)
%  IndexofProblem='LA05-RM';
%  CreateGanttDiagram(SolutionRightMove,IndexofProblem)
solution=RepresentationOfBestSolutionFromGEP(solution,problemSet);

OperationsNum=problemSet.problemSize.totalOperationsNumber;
MachineNum=problemSet.problemSize.machinesNumber;
JobNum=problemSet.problemSize.jobsNumber;

operationsScheduleAfterLeftMove=zeros(OperationsNum,8);
operationsSchedule=solution.operationsSchedule;

operationsScheduleAfterLeftMove(:,1:3)=operationsSchedule(:,1:3);
operationsScheduleAfterLeftMove(:,7:8)=operationsSchedule(:,7:8);
operationsScheduleAfterLeftMove(:,4)=0;

FirstOperationsOfJobs=zeros(JobNum,1);
LastOperationsOfJobs=zeros(JobNum,1);
for i=1:JobNum
  FirstOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(1);
  LastOperationsOfJobs(i,1)=  problemSet.jobsSet{i,5}(end);
end

FirstOperationsOnMachines=zeros(MachineNum,1);

for j=1:MachineNum
    if numel(solution.machinesSchedule{j,1})>0
        FirstOperationsOnMachines(j,1)=solution.machinesSchedule{j,1}(1);
    end
end 

for i=1:(OperationsNum-1)
    operation=solution.OperationSequencingList(i,4);
    startingTime=operationsSchedule(operation,6);
    % (operation+1) of the same job should end before this opeartion
    Index=find(LastOperationsOfJobs==operation);
    if numel(Index)==0
        operationsScheduleAfterLeftMove(operation+1,4)=startingTime;
    end
end

BlocksOnMachines=zeros(size(solution.IdlePositionOnMachine,1),3*MachineNum);
BlocksNum=0;
BlocksStartingTime=[];
BlocksNumOnMachine=zeros(MachineNum,1);
for j=1:MachineNum
    for n=1:(size(BlocksOnMachines,1)-1)
        StartingOperation=cell2mat(solution.IdlePositionOnMachine(n,2*j));
        endingOperation=cell2mat(solution.IdlePositionOnMachine(n+1,2*j-1));
        if numel(StartingOperation)>1
            Starting=find(operationsSchedule(:,2)==StartingOperation(1) & operationsSchedule(:,3)==StartingOperation(2));
            ending=find(operationsSchedule(:,2)==endingOperation(1) & operationsSchedule(:,3)==endingOperation(2));
            startingTime=operationsSchedule(Starting(1),5);
            BlocksOnMachines(n,3*j)=startingTime;
            BlocksOnMachines(n,3*j-1)=ending(1);
            BlocksOnMachines(n,3*j-2)=Starting(1);
            BlocksNum=BlocksNum+1;
            BlocksNumOnMachine(j)=BlocksNumOnMachine(j)+1;
            Add=[startingTime,j,BlocksNumOnMachine(j)];
            BlocksStartingTime=[BlocksStartingTime;Add];
        end
    end
end

BlocksStartingTime=sortrows(BlocksStartingTime,1);
MachineTime=zeros(MachineNum,1);

for step=1:BlocksNum
%     close all;
    Machine=BlocksStartingTime(step,2);
    BlocksIndex=BlocksStartingTime(step,3);
    
    startingOperation=BlocksOnMachines(BlocksIndex,3*Machine-2);
    endingOperation=BlocksOnMachines(BlocksIndex,3*Machine-1);
    operationsonMachine=cell2mat(solution.machinesSchedule(Machine,1));
    Index1=find(operationsonMachine==startingOperation);
    Index2=find(operationsonMachine==endingOperation);
    operations=operationsonMachine(1,Index1(1):Index2(1));
    
    upload=cell2mat(problemSet.machinesSet(Machine,5));
    switchoff=cell2mat(problemSet.machinesSet(Machine,6));
    
    EndingTimeOfThisBlock=operationsSchedule(endingOperation,6);
    StartingTimeOfThisBlock=operationsSchedule(startingOperation,5);
    
    if BlocksNumOnMachine(Machine,1)>1 && BlocksIndex>1
        operationPredecessor=operationsonMachine(Index1(1)-1);
        EndingTimeOfoperationPredecessor=operationsSchedule(operationPredecessor,6);
    end
    if BlocksNumOnMachine(Machine,1)>1 && BlocksIndex<BlocksNumOnMachine(Machine,1)
        operationSuccessor=operationsonMachine(Index2(1)+1);
        StartingTimeOfoperationSuccessor=operationsSchedule(operationSuccessor,5);
    end
    
    % check scenario of block
    if BlocksNumOnMachine(Machine,1)==1
        %*** Scenario 1-Total block move
        operationsSchedule=LeftMoveTypeI(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine,StartingTimeOfThisBlock);
    end
    
    if BlocksNumOnMachine(Machine,1)>1 &&  BlocksIndex==1
        %*** Scenario 2 or 3
        if (StartingTimeOfoperationSuccessor-EndingTimeOfThisBlock)*upload>=switchoff
            % Scenario 2-MoveI-Total block move
            operationsSchedule=LeftMoveTypeIV(LastOperationsOfJobs,operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOnMachines,StartingTimeOfThisBlock,MachineTime,Machine);
        end
    end
    if BlocksNumOnMachine(Machine,1)>1 && BlocksIndex<BlocksNumOnMachine(Machine,1) && BlocksIndex>1
        %*** Scenario 4-7
        if (StartingTimeOfoperationSuccessor-EndingTimeOfThisBlock)*upload>switchoff && (StartingTimeOfThisBlock-EndingTimeOfoperationPredecessor)*upload>switchoff
            %Scenario 4- Move II
            operationsSchedule=LeftMoveTypeII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine,StartingTimeOfThisBlock);
        end
        if (StartingTimeOfoperationSuccessor-EndingTimeOfThisBlock)*upload>switchoff && (StartingTimeOfThisBlock-EndingTimeOfoperationPredecessor)*upload<=switchoff
            %Scenario 5- Move III
            operationsSchedule=LeftMoveTypeIII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine);
        end
        if (StartingTimeOfoperationSuccessor-EndingTimeOfThisBlock)*upload<=switchoff && (StartingTimeOfThisBlock-EndingTimeOfoperationPredecessor)*upload>switchoff
            %Scenario 6- Move II
            PreviousSolution.operationsSchedule=operationsSchedule;
            PreviousSolution = TransformOperationsScheduleToMachinesSchedule(problemSet,PreviousSolution);
            PreviousSolution = CalculateObjectiveFunctions(problemSet,PreviousSolution);
            operationsSchedule=LeftMoveTypeII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine,StartingTimeOfThisBlock);
            
            AfterMoveSolution.operationsSchedule=operationsSchedule;
            AfterMoveSolution = TransformOperationsScheduleToMachinesSchedule(problemSet,AfterMoveSolution);
            AfterMoveSolution = CalculateObjectiveFunctions(problemSet,AfterMoveSolution);
            if AfterMoveSolution.obj>PreviousSolution.obj
                operationsSchedule=PreviousSolution.operationsSchedule;
            end
        end
        if (StartingTimeOfoperationSuccessor-EndingTimeOfThisBlock)*upload<=switchoff && (StartingTimeOfThisBlock-EndingTimeOfoperationPredecessor)*upload<=switchoff
            %Scenario 7- Move III
            operationsSchedule=LeftMoveTypeIII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine);
        end 
    end
    
    if BlocksNumOnMachine(Machine,1)>1 &&  BlocksIndex==BlocksNumOnMachine(Machine,1)
        %*** Scenario 8-9
        if (StartingTimeOfThisBlock-EndingTimeOfoperationPredecessor)*upload<=switchoff
            % Scenario 8 - Move III
            operationsSchedule=LeftMoveTypeIII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine);
        else
            % Scenario 9- Move II
            operationsSchedule=LeftMoveTypeII(operations,operationsSchedule,operationsScheduleAfterLeftMove,FirstOperationsOfJobs,MachineTime,Machine,StartingTimeOfThisBlock);
        end
    end
    
    for i=1:numel(operations)
        operation=operations(i);
        operationsScheduleAfterLeftMove(operation,6)=operationsSchedule(operation,6);
        operationsScheduleAfterLeftMove(operation,5)=operationsSchedule(operation,5);
        if i==numel(operations)
            MachineTime(Machine,1)=operationsSchedule(operation,6);
        end
    end
    % update
    for i=1:(OperationsNum-1)
        operation=solution.OperationSequencingList(i,4);
        startingTime=operationsSchedule(operation,6);
        % (operation+1) of the same job should end before this opeartion
        Index=find(LastOperationsOfJobs==operation);
        if numel(Index)==0
            operationsScheduleAfterLeftMove(operation+1,4)=startingTime;
        end
    end
% SolutionLeftMove.operationsSchedule=operationsScheduleAfterLeftMove;
% 
% SolutionLeftMove.machinesSchedule=solution.machinesSchedule;
% 
% SolutionLeftMove=RepresentationOfBestSolutionFromGEP(SolutionLeftMove,problemSet);
% 
% [SolutionLeftMove] = CalculateObjectiveFunctions(problemSet,SolutionLeftMove);
% 
% 
%  IndexofProblem='LA05-RLM';
%  CreateGanttDiagram(SolutionLeftMove,IndexofProblem)
end
SolutionLeftMove.operationsSchedule=operationsScheduleAfterLeftMove;

SolutionLeftMove.machinesSchedule=solution.machinesSchedule;

SolutionLeftMove=RepresentationOfBestSolutionFromGEP(SolutionLeftMove,problemSet);

[SolutionLeftMove] = CalculateObjectiveFunctions(problemSet,SolutionLeftMove);
% IndexofProblem='LA05-RLM';
% CreateGanttDiagram(SolutionLeftMove,IndexofProblem);

end